
# Changelog

All notable changes to this project will be documented in this file.

## [2.2.0-alpha] - 2025-12-28

### 🚀 Features & Enhancements

#### 📻 Radio System Overhaul
- **Smart Queue Management:** The system now intelligently checks the "Play Deck" status. If the queue is empty during a play attempt, users are prompted to initiate a `scan` command rather than the player failing silently.
- **Audio Frequency Visualizer:** Integrated the Web Audio API to drive a real-time visualizer in the Radio Bar. This provides immediate, high-fidelity visual feedback for audio playback activity.
- **Self-Healing Audio Playback:**
  - Implemented advanced error interception for the media player.
  - **Auto-Recovery Protocol:** Upon encountering a file not found (404) or decoding error, the system automatically:
    1. Logs the specific error to the terminal for transparency.
    2. Triggers a background `radio scan` to refresh the local manifest.
    3. Advances to the next track in the queue to maintain continuous broadcasting without user intervention.

#### 📁 Codex & File System
- **Image Preview Restoration:** Fixed a critical bug in the Codex component preventing image previews from loading. The fix involves a more robust method for generating signed URLs from Supabase Storage, bypassing previous directory listing failures that caused broken images.

### 🔧 Maintenance
- **Version Control:** Bumped application version to `2.2.0-alpha` to reflect the stability improvements in the media and file handling subsystems.
