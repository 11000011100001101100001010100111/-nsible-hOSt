
import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

const b64DecodeUnicode = (str) => {
  try {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (e) {
    return str;
  }
};

const CYCLE_SECONDS = 42 * 60 + 8; // ~2528 seconds
const POLLING_INTERVAL = (CYCLE_SECONDS / 10) * 1000; // 1/10th of a cycle in ms (~252.8s)

export const useFileSystem = (user, isAuthLoading, addCommandOutput, addToQueue, logTimelineEvent) => {
  const [fileSystem, setFileSystem] = useState({});
  const [currentPath, setCurrentPath] = useState([]); // Array of keys (folder names as stored in DB)
  const pollTimerRef = useRef(null);

  // Fetch function
  const fetchFS = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('user_filesystems')
      .select('filesystem')
      .eq('user_id', user.id)
      .single();

    if (data && data.filesystem) {
      setFileSystem(data.filesystem);
    } else if (error && error.code !== 'PGRST116') {
      console.error('Filesystem load error:', error);
    }
  }, [user]);

  // 1. Initial Fetch & Subscription & Polling
  useEffect(() => {
    if (!user) return;
    
    // Initial load
    fetchFS();

    // Set up Realtime Subscription
    const channel = supabase.channel(`fs_update_${user.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'user_filesystems', filter: `user_id=eq.${user.id}` },
        (payload) => {
          if (payload.new && payload.new.filesystem) {
            setFileSystem(payload.new.filesystem);
            if (logTimelineEvent) logTimelineEvent('system', 'Filesystem Sync', 'Received real-time update.');
          }
        }
      )
      .subscribe((status) => {
         // Subscription status handling if needed
      });

    // Set up Polling (Fallback/Consistency Check)
    pollTimerRef.current = setInterval(() => {
       fetchFS();
    }, POLLING_INTERVAL);

    return () => {
        supabase.removeChannel(channel);
        if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    };
  }, [user, fetchFS, logTimelineEvent]);

  // Helper to traverse the FS tree
  const resolveNode = useCallback((fs, pathKeys) => {
    let current = fs;
    for (const key of pathKeys) {
      if (current && current[key] && current[key].type === 'folder') {
        current = current[key].content;
      } else {
        return null;
      }
    }
    return current;
  }, []);

  const getCurrentDirectory = useCallback((fs, path) => {
    return resolveNode(fs, path);
  }, [resolveNode]);

  // Generic Update Function (Exposed for Codex)
  const updateFileSystem = useCallback(async (actionDescription, { key, value, delete: del, append, path, silent } = {}) => {
      if (!user) return;
      
      const targetPath = path !== undefined ? path : currentPath;

      const { error } = await supabase.rpc('upsert_filesystem_entry', {
          p_user_id: user.id,
          p_path: targetPath,
          p_key: key,
          p_value: value,
          p_delete: !!del,
          p_append: !!append 
      });

      if (error) {
          if (!silent) addCommandOutput({ type: 'error', title: 'System', message: error.message });
          throw error;
      } else {
          // Trigger immediate fetch to ensure sync if realtime is slow
          fetchFS();
          
          if (!silent) addCommandOutput({ type: 'success', title: 'System', message: actionDescription });
          if (logTimelineEvent && !silent) logTimelineEvent('file_op', 'File System Update', actionDescription);
      }
  }, [user, currentPath, addCommandOutput, logTimelineEvent, fetchFS]);


  // --- COMMANDS ---

  const handleLs = useCallback((arg) => {
    // 1. Resolve Target Path
    let targetPath = [...currentPath];

    if (arg) {
      if (arg === '/') {
        targetPath = [];
      } else if (arg === '..') {
        if (targetPath.length > 0) targetPath.pop();
      } else {
        // Attempt to find directory in current path
        const currentNode = resolveNode(fileSystem, currentPath);
        if (!currentNode) {
           addCommandOutput({ type: 'error', title: 'System', message: 'Current path invalid.' });
           return;
        }
        
        // Match key by decoded name or raw key
        const foundKey = Object.keys(currentNode).find(k => b64DecodeUnicode(k) === arg || k === arg);
        
        if (foundKey) {
             if (currentNode[foundKey].type === 'folder') {
                 targetPath.push(foundKey);
             } else {
                 addCommandOutput({ type: 'error', title: 'ls', message: `'${arg}' is not a directory.` });
                 return;
             }
        } else {
            addCommandOutput({ type: 'error', title: 'ls', message: `Directory '${arg}' not found.` });
            return;
        }
      }
    }

    // 2. Get Content
    const node = resolveNode(fileSystem, targetPath);
    if (!node) {
       addCommandOutput({ type: 'error', title: 'ls', message: 'Target directory does not exist.' });
       return;
    }

    // 3. Format Output (Initial Snapshot)
    const items = Object.entries(node).map(([key, val]) => ({
      name: b64DecodeUnicode(key),
      type: val.type
    }));

    // Generate Display Path String
    const pathStr = targetPath.length === 0 ? '~' : '~/' + targetPath.map(k => b64DecodeUnicode(k)).join('/');
    
    // Pass 'pathKeys' to allow the LsOutput component to subscribe to live changes
    addCommandOutput({ type: 'ls', items, path: pathStr, pathKeys: targetPath });

  }, [fileSystem, currentPath, addCommandOutput, resolveNode]);

  const handleCd = useCallback((arg) => {
    if (!arg || arg === '~') {
      setCurrentPath([]);
      return;
    }
    if (arg === '..') {
      setCurrentPath(prev => prev.slice(0, -1));
      return;
    }
    
    const currentNode = resolveNode(fileSystem, currentPath);
    if (!currentNode) {
         addCommandOutput({ type: 'error', title: 'cd', message: 'Current directory structure invalid.' });
         return;
    }
    
    // Find matching key
    const foundKey = Object.keys(currentNode).find(k => b64DecodeUnicode(k) === arg || k === arg);
    
    if (foundKey && currentNode[foundKey].type === 'folder') {
        setCurrentPath(prev => [...prev, foundKey]);
    } else {
        addCommandOutput({ type: 'error', title: 'cd', message: `Directory '${arg}' not found.` });
    }
  }, [fileSystem, currentPath, addCommandOutput, resolveNode]);

  const handleMkdir = useCallback(async (name) => {
    if (!user || !name) return;
    const { error } = await supabase.rpc('upsert_filesystem_entry', {
      p_user_id: user.id,
      p_path: currentPath,
      p_key: name,
      p_value: { type: 'folder', content: {} }
    });
    if (error) addCommandOutput({ type: 'error', title: 'mkdir', message: error.message });
    else {
        addCommandOutput({ type: 'success', title: 'mkdir', message: `Directory '${name}' created.` });
        if(logTimelineEvent) logTimelineEvent('file_op', 'Directory Created', `Created directory: ${name}`);
        fetchFS(); // Sync immediately
    }
  }, [user, currentPath, addCommandOutput, logTimelineEvent, fetchFS]);

  const handleTouch = useCallback(async (name) => {
    if (!user || !name) return;
    const { error } = await supabase.rpc('upsert_filesystem_entry', {
      p_user_id: user.id,
      p_path: currentPath,
      p_key: name,
      p_value: { type: 'file', content: '', storagePath: '' }
    });
    if (error) addCommandOutput({ type: 'error', title: 'touch', message: error.message });
    else {
        addCommandOutput({ type: 'success', title: 'touch', message: `File '${name}' created.` });
        if(logTimelineEvent) logTimelineEvent('file_op', 'File Created', `Created file: ${name}`);
        fetchFS(); // Sync immediately
    }
  }, [user, currentPath, addCommandOutput, logTimelineEvent, fetchFS]);

  const handleRm = useCallback(async (name) => {
    if (!user || !name) return;
    const { error } = await supabase.rpc('upsert_filesystem_entry', {
        p_user_id: user.id,
        p_path: currentPath,
        p_key: name,
        p_delete: true
    });
    if (error) addCommandOutput({ type: 'error', title: 'rm', message: error.message });
    else {
        addCommandOutput({ type: 'success', title: 'rm', message: `Deleted '${name}'.` });
        if(logTimelineEvent) logTimelineEvent('file_op', 'File Removed', `Removed item: ${name}`);
        fetchFS(); // Sync immediately
    }
  }, [user, currentPath, addCommandOutput, logTimelineEvent, fetchFS]);

  const catFile = useCallback((name) => {
      const node = resolveNode(fileSystem, currentPath);
      const key = Object.keys(node || {}).find(k => b64DecodeUnicode(k) === name || k === name);
      
      if (key && node[key].type === 'file') {
          addCommandOutput({ type: 'info', title: name, message: node[key].content || '(empty)' });
      } else {
          addCommandOutput({ type: 'error', title: 'cat', message: 'File not found.' });
      }
  }, [fileSystem, currentPath, addCommandOutput, resolveNode]);

  const handleCp = useCallback(() => addCommandOutput({ type: 'info', title: 'cp', message: 'Not implemented yet.' }), [addCommandOutput]);
  const handleMv = useCallback(() => addCommandOutput({ type: 'info', title: 'mv', message: 'Not implemented yet.' }), [addCommandOutput]);

  return {
    fileSystem,
    currentPath,
    setCurrentPath,
    getCurrentDirectory,
    updateFileSystem,
    handleLs,
    handleCd,
    handleMkdir,
    handleTouch,
    handleRm,
    handleCp,
    handleMv,
    catFile
  };
};
