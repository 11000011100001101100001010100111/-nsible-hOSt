
import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/contexts/ThemeContext';
import { useFileSystem } from '@/hooks/useFileSystem';
import { generateFrequency } from '@/lib/utils';
import { useTemporal } from '@/contexts/TemporalContext';

const DeskContext = createContext();

const b64DecodeUnicode = (str) => {
  try {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (e) {
    return str;
  }
};

export const useDesk = () => {
  const context = useContext(DeskContext);
  if (!context) {
    throw new Error('useDesk must be used within a DeskProvider');
  }
  return context;
};

export const DeskProvider = ({ children }) => {
  const { user, loading: isAuthLoading, refreshProfile } = useAuth();
  const { toast } = useToast();
  const { theme } = useTheme(); 
  const { addEvent: logTimelineEvent } = useTemporal();

  const [isDeskOpen, setIsDeskOpen] = useState(false);
  const [isDeskLoading, setIsDeskLoading] = useState(false);
  
  // State for command output
  const [commandHistory, setCommandHistory] = useState([]);
  const [backgroundActivity, setBackgroundActivity] = useState(false);
  const [activePanel, setActivePanel] = useState('terminal'); // 'terminal', 'codex', 'forum', 'timeline'

  // State for MessageCenter/Timeline
  const [timelinePosition, setTimelinePosition] = useState(100);

  // State for Codex/Editor
  const [editingFile, setEditingFile] = useState(null);

  // --- Output Manager ---
  const addCommandOutput = (outputItem) => {
    setCommandHistory(prev => [...prev, { ...outputItem, id: Date.now() + Math.random() }]);
    if (!isDeskOpen) {
        setBackgroundActivity(true);
    } else {
        if (outputItem.type !== 'command') {
            setActivePanel('terminal');
        }
    }
  };

  const clearCommandHistory = () => {
    setCommandHistory([]);
  };

  // --- Audio State ---
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);
  const [audioQueue, setAudioQueue] = useState([]);
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  
  // Refs for Audio System
  const audioRef = useRef(null);
  const analyserRef = useRef(null); 

  const [mediaLibrary, setMediaLibrary] = useState([]);
  const [isRadioVisible, setRadioVisible] = useState(false); 

  const addToQueue = (track) => {
      setAudioQueue(prev => [...prev, track]);
      toast({ title: "Audio System", description: `${track.title} added to queue.` });
  };
  
  // --- Audio Control Functions (Function Declarations for Hoisting/Recursion) ---

  async function playTrack(track) {
      if (!track) return;
      
      // Check 1: Empty track data
      if (!track.storagePath && (!track.src || track.src.trim() === '')) {
          handleAudioError(`File '${track.title}' is empty or has no audio data.`);
          return;
      }

      setRadioVisible(true); 
      let playableTrack = track;
      
      // Check 2: Storage download needed
      if (track.storagePath && (!track.src || (!track.src.startsWith('blob:') && !track.src.startsWith('http')))) {
         try {
             const { data, error } = await supabase.storage.from('user_files').download(track.storagePath);
             if (data) {
                 const blobUrl = URL.createObjectURL(data);
                 playableTrack = { ...track, src: blobUrl };
                 logTimelineEvent('media', 'File Downloaded', `Downloaded audio for playback: ${track.title}`);
             } else {
                 console.error("Download error:", error);
                 handleAudioError(`Could not retrieve audio file '${track.title}'.`);
                 return;
             }
         } catch(e) {
             console.error("Audio download exception", e);
             handleAudioError(`Audio download crashed for '${track.title}'.`);
             return;
         }
      }

      setCurrentTrack(playableTrack);
      setIsPlaying(true);
  }

  function playNextInQueue() {
      if (audioQueue.length > 0) {
          const next = audioQueue[0];
          setAudioQueue(prev => prev.slice(1));
          playTrack(next);
      } else {
          stopAudio();
      }
  }

  function playPreviousInQueue() {
      if (audioRef.current) seekTo(0); 
  }

  function stopAudio() {
      setIsPlaying(false); 
      setCurrentTrack(null); 
      setAudioProgress(0); 
  }

  function seekTo(time) { 
      if (audioRef.current) { 
          audioRef.current.currentTime = time; 
          setAudioProgress(time); 
      } 
  }

  function shuffleQueue() { 
      setAudioQueue(prev => [...prev].sort(() => Math.random() - 0.5)); 
      toast({ title: "Audio", description: "Queue shuffled." }); 
  }

  function toggleBroadcast() { 
      setIsBroadcasting(!isBroadcasting); 
      toast({ title: isBroadcasting ? "Broadcast Ends" : "Broadcast Live", description: isBroadcasting ? "Signal cut." : "Signal active." }); 
  }

  function clearQueue() { 
      setAudioQueue([]); 
      stopAudio(); 
  }

  function togglePlay() {
      setRadioVisible(true);

      if (!currentTrack && audioQueue.length === 0) {
          const found = scanMedia();
          if (found.length > 0) {
              setAudioQueue(found);
              playTrack(found[0]);
              return;
          } else {
             toast({ title: "Radio System", description: "No media detected in filesystem.", variant: "destructive" });
             setIsPlaying(false);
             return;
          }
      } 
      
      else if (!currentTrack && audioQueue.length > 0) {
          playTrack(audioQueue[0]);
          return;
      }
      
      setIsPlaying(!isPlaying);
  }

  // --- File System Hook ---
  const fsProps = useFileSystem(user, isAuthLoading, addCommandOutput, addToQueue, logTimelineEvent);

  // --- Media Scanner & Auto-Population ---
  const scanMedia = () => {
      if (!fsProps.fileSystem) return [];
      const found = [];
      const traverse = (obj, pathParts = []) => {
          Object.entries(obj).forEach(([key, val]) => {
              const decodedName = b64DecodeUnicode(key);
              
              if (val.type === 'file' && /\.(mp3|wav|ogg)$/i.test(val.name || decodedName)) {
                   found.push({ 
                       name: val.name || decodedName, 
                       src: val.storagePath || '', 
                       title: val.name || decodedName, 
                       storagePath: val.storagePath 
                   });
              } else if (val.type === 'folder') {
                  traverse(val.content, [...pathParts, key]);
              }
          });
      };
      traverse(fsProps.fileSystem);
      setMediaLibrary(found);
      return found;
  };

  // --- Audio Error Handler ---
  const handleAudioError = (message) => {
      addCommandOutput({ 
          type: 'error', 
          title: "Audio Failure", 
          message: message || "Signal dropped." 
      });
      
      // Run radio scan logic (refresh library) before playing next
      addCommandOutput({ type: 'info', title: 'System', message: 'Running radio scan...' });
      scanMedia();
      
      playNextInQueue();
  };

  useEffect(() => {
    if (fsProps.fileSystem && Object.keys(fsProps.fileSystem).length > 0) {
       const media = scanMedia();
       if (media.length > 0 && audioQueue.length === 0 && !currentTrack) {
          setAudioQueue(media);
       }
    }
  }, [fsProps.fileSystem]);


  // --- Frequency & Broadcast Logic ---
  const [userFrequency, setUserFrequency] = useState(null);

  useEffect(() => {
    const initFrequency = async () => {
      if (!user) return;
      
      let freq = user.profile?.profile_info?.frequency;
      
      if (!freq) {
        freq = generateFrequency(user.id);
        const newProfileInfo = { ...(user.profile?.profile_info || {}), frequency: freq };
        
        const { error } = await supabase
          .from('users')
          .update({ profile_info: newProfileInfo })
          .eq('id', user.id);
          
        if (error) {
          console.error("Failed to assign frequency:", error);
        } else {
          setUserFrequency(freq);
          addCommandOutput({ type: 'success', title: 'Signal Established', message: `Frequency assigned: ${freq}` });
        }
      } else {
        setUserFrequency(freq);
      }
    };
    
    initFrequency();
  }, [user]);

  // --- BROADCAST SYNC LOGIC ---
  useEffect(() => {
      if (!user || !userFrequency) return;
      
      let debounceTimer;

      const syncBroadcast = async () => {
          if (!isBroadcasting) return;

          let broadcastPayload = {
              isPlaying: false,
              track: null,
              timestamp: Date.now()
          };

          if (currentTrack) {
              let publicUrl = null;
              if (currentTrack.storagePath) {
                   const { data } = await supabase.storage.from('user_files').createSignedUrl(currentTrack.storagePath, 3600); 
                   if (data) publicUrl = data.signedUrl;
              }

              broadcastPayload = {
                  isPlaying,
                  track: {
                      title: currentTrack.title || 'Unknown Signal',
                      artist: currentTrack.artist || user.username,
                      url: publicUrl, 
                      duration: audioDuration
                  },
                  timestamp: Date.now()
              };
          }

          const channel = supabase.channel(`broadcast:${userFrequency}`);
          channel.subscribe(async (status) => {
               if (status === 'SUBSCRIBED') {
                   await channel.send({
                       type: 'broadcast',
                       event: 'track_update',
                       payload: broadcastPayload
                   });
                   supabase.removeChannel(channel);
               }
          });

          const newProfileInfo = { 
              ...(user.profile?.profile_info || {}), 
              frequency: userFrequency,
              broadcast_state: broadcastPayload
          };
          
          await supabase.from('users').update({ profile_info: newProfileInfo }).eq('id', user.id);
      };

      if (isBroadcasting) {
          debounceTimer = setTimeout(syncBroadcast, 500);
      }

      return () => clearTimeout(debounceTimer);
  }, [currentTrack, isPlaying, isBroadcasting, user, userFrequency, audioDuration]);


  const fetchUserByFrequency = async (freq) => {
     const { data, error } = await supabase
        .from('users')
        .select('*')
        .filter('profile_info->>frequency', 'eq', freq)
        .single();
     
     if (error) return null;
     return data;
  };

  const fetchUserByUsername = async (username) => {
     const clean = username.replace('@', '');
     const { data, error } = await supabase
        .from('users')
        .select('*')
        .ilike('username', clean)
        .single();
     
     if (error) return null;
     return data;
  };

  const publishBroadcast = async (content) => {
      if (!user) return;
      const { error } = await supabase
          .from('users')
          .update({ public_page_html: content })
          .eq('id', user.id);
      if (error) {
          addCommandOutput({ type: 'error', title: 'Broadcast Error', message: error.message });
          throw error;
      } else {
          await refreshProfile(); // Refresh local user state to reflect changes immediately
          addCommandOutput({ type: 'success', title: 'Broadcast', message: `Signal Updated on ${userFrequency}` });
          toast({ title: "Broadcast Updated", description: "Your public signal has been updated." });
          logTimelineEvent('system', 'Broadcast Published', `Updated public signal on frequency ${userFrequency}`);
      }
  };
  
  const getBroadcastLink = () => {
    if (!userFrequency) return null;
    const match = userFrequency.match(/^([A-Z0-9]+)-(.+)$/);
    if (match) {
        return `https://ætatic.tech/${match[1]}/${match[2]}`;
    }
    return `https://ætatic.tech/FREQ/${userFrequency}`;
  };

  // --- Modulation Logic ---
  const [activeModulations, setActiveModulations] = useState([]);
  
  useEffect(() => {
    if (!user) return;
    if (userFrequency && !userFrequency.startsWith('XMF')) return;
    const fetchModulations = async () => {
        const { data, error } = await supabase
           .from('modulations')
           .select('*')
           .eq('status', 'pending')
           .gt('expires_at', new Date().toISOString());
        if (!error && data) setActiveModulations(data);
    };
    fetchModulations();
    const modChannel = supabase.channel('public:modulations')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'modulations' }, (payload) => {
          if (payload.eventType === 'INSERT' && payload.new.status === 'pending') {
             setActiveModulations(prev => [...prev, payload.new]);
             toast({ title: 'System', description: 'New modulation vote initiated.' });
             if (!isDeskOpen) setBackgroundActivity(true);
             setActivePanel('forum');
             logTimelineEvent('system', 'Modulation Vote', 'New voting session detected.');
          } else if (payload.eventType === 'UPDATE') {
             setActiveModulations(prev => prev.map(m => m.id === payload.new.id ? payload.new : m));
          }
      })
      .subscribe();
    return () => supabase.removeChannel(modChannel);
  }, [user, userFrequency, isDeskOpen, setActivePanel, logTimelineEvent]);

  const startModulation = async (targetUsername) => {
      const target = await fetchUserByUsername(targetUsername);
      if (!target) throw new Error(`Target ${targetUsername} not found.`);
      const cycleSeconds = 42 * 60 + 8;
      const expiresAt = new Date(Date.now() + cycleSeconds * 1000).toISOString();
      const { data, error } = await supabase.from('modulations').insert({
          initiator_id: user.id,
          target_username: target.username,
          expires_at: expiresAt,
          status: 'pending'
      }).select().single();
      if (error) throw error;
      const msgContent = `[SYSTEM::MODULATION] User @${user.username} initiated XMF elevation for @${target.username}. Binary vote required.`;
      await supabase.from('messages').insert({
          sender_id: user.id,
          sender_username: '@nsible_System',
          recipient_id: user.id,
          content: msgContent,
          is_broadcast: true,
          is_read: false
      });
      addCommandOutput({ type: 'success', title: 'Modulation', message: `Vote initiated for @${target.username}. Cycle duration set.` });
      logTimelineEvent('system', 'Modulation Initiated', `Started XMF vote for ${target.username}`);
      return data;
  };

  const castVote = async (modulationId, value) => {
      const { data: mod, error: fetchError } = await supabase.from('modulations').select('*').eq('id', modulationId).single();
      if (fetchError) throw fetchError;
      let votes = mod.votes || [];
      votes = votes.filter(v => v.voter_id !== user.id);
      votes.push({ voter_id: user.id, value: value === 1 ? 1 : 0 });
      const { error } = await supabase.from('modulations').update({ votes }).eq('id', modulationId);
      if (error) throw error;
      addCommandOutput({ type: 'info', title: 'Vote Cast', message: `Value: ${value}` });
  };
  
  // --- Messaging ---
  const [hasUnreadMessages, setHasUnreadMessages] = useState(false);

  useEffect(() => {
      if (!user) return;
      const checkUnread = async () => {
          const { count, error } = await supabase.from('messages').select('*', { count: 'exact', head: true }).eq('recipient_id', user.id).eq('is_read', false);
          if (!error) setHasUnreadMessages(count > 0);
      };
      checkUnread();
      const msgChannel = supabase.channel('public:messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `recipient_id=eq.${user.id}`}, (payload) => {
          setHasUnreadMessages(true);
          toast({ title: "Transmission", description: `New message from ${payload.new.sender_username || 'Unknown'}.` });
          if (!isDeskOpen) setBackgroundActivity(true);
          else setActivePanel('forum');
      })
      .subscribe();
      return () => supabase.removeChannel(msgChannel);
  }, [user, toast, isDeskOpen]);

  // --- Device Detection for Folding Phones (RAZR, etc) ---
  useEffect(() => {
    if (!user) return;
    const ua = navigator.userAgent.toLowerCase();
    // Check for common folding device keywords in User Agent
    const isFolding = /(razr|flip|fold|sm-f|pixel fold)/i.test(ua);
    const ackKey = 'razr_easter_egg_sent';

    if (isFolding && !localStorage.getItem(ackKey)) {
        const sendEgg = async () => {
            const { error } = await supabase.from('messages').insert({
                sender_id: user.id,
                recipient_id: user.id,
                sender_username: 'hello.moto',
                content: 'Hello Moto. Form factor detected. Interface reconfigured for style and function.',
                is_broadcast: false,
                is_read: false
            });
            
            if (!error) {
                toast({
                    title: "System Optimized",
                    description: "Interface adjusted for folding device parameters.",
                    duration: 4000
                });
                addCommandOutput({ 
                    type: 'success', 
                    title: 'System', 
                    message: 'Form factor detected: FOLDING. UI Optimized.' 
                });
                localStorage.setItem(ackKey, 'true');
            }
        };
        sendEgg();
    }
  }, [user, toast]);

  // --- Actions ---
  const openDesk = () => {
    setIsDeskLoading(true);
    setBackgroundActivity(false); 
    setTimeout(() => {
      setIsDeskOpen(true);
      setIsDeskLoading(false);
    }, 800);
  };

  const closeDesk = () => setIsDeskOpen(false);

  const logToVoid = async (content) => {
      if (!user) return;
      try { await supabase.rpc('log_to_void', { p_user_id: user.id, p_content: content }); } catch (e) { console.error("Void log failed:", e); }
  };
  
  // Web Frame
  const [webFrameState, setWebFrameState] = useState({ url: null, isOpen: false, isMinimized: false, title: 'Node' });
  const openWebFrame = (url, title = 'Node') => setWebFrameState({ url, title, isOpen: true, isMinimized: false });
  const closeWebFrame = () => setWebFrameState(prev => ({ ...prev, isOpen: false }));
  const toggleWebFrameMinimize = () => setWebFrameState(prev => ({ ...prev, isMinimized: !prev.isMinimized }));

  const value = {
    isDeskOpen, openDesk, closeDesk, isDeskLoading,
    commandHistory, addCommandOutput, clearCommandHistory,
    hasUnreadMessages, setHasUnreadMessages, logToVoid,
    activePanel, setActivePanel, backgroundActivity, setBackgroundActivity,
    timelinePosition, setTimelinePosition,
    
    // File System from Hook
    ...fsProps,

    // Editor State
    editingFile, setEditingFile,

    // Audio
    currentTrack, setCurrentTrack, isPlaying, setIsPlaying, volume, setVolume, isMuted, setIsMuted,
    audioProgress, setAudioProgress, audioDuration, setAudioDuration, audioRef, analyserRef, playTrack, togglePlay,
    stopAudio, seekTo, audioQueue, addToQueue, playNextInQueue, playPreviousInQueue, shuffleQueue,
    isBroadcasting, toggleBroadcast, mediaLibrary, scanMedia, clearQueue,
    isRadioVisible, setRadioVisible,
    handleAudioError,

    // Web Frame
    webFrameState, openWebFrame, closeWebFrame, toggleWebFrameMinimize,

    // Frequency & Broadcast
    userFrequency,
    fetchUserByFrequency,
    fetchUserByUsername,
    publishBroadcast,
    getBroadcastLink,

    // Modulation
    startModulation,
    activeModulations,
    castVote
  };

  return <DeskContext.Provider value={value}>{children}</DeskContext.Provider>;
};
