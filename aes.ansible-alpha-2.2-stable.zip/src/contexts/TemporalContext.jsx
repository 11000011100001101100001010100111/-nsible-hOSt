
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const TemporalContext = createContext();

export const useTemporal = () => {
  const context = useContext(TemporalContext);
  if (!context) {
    throw new Error('useTemporal must be used within a TemporalProvider');
  }
  return context;
};

export const TemporalProvider = ({ children }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Real-time clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const normalizeMessage = (msg) => ({
    id: msg.id,
    created_at: msg.created_at,
    event_type: 'message',
    title: msg.sender_username || 'Unknown Signal',
    description: msg.content,
    metadata: { 
        is_broadcast: msg.is_broadcast, 
        is_read: msg.is_read,
        original_id: msg.id 
    }
  });

  const fetchEvents = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    // Fetch Timeline Events (System logs, etc)
    const { data: timelineData, error: timelineError } = await supabase
      .from('timeline_events')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);

    if (timelineError) console.error("Timeline fetch error:", timelineError);

    // Fetch Messages (Communications)
    const { data: messageData, error: messageError } = await supabase
        .from('messages')
        .select('*')
        .or(`recipient_id.eq.${user.id},is_broadcast.eq.true`)
        .order('created_at', { ascending: false })
        .limit(50);

    if (messageError) console.error("Message fetch error:", messageError);

    const normalizedMessages = (messageData || []).map(normalizeMessage);
    
    // Combine and Sort
    const combined = [...(timelineData || []), ...normalizedMessages]
        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    setEvents(combined);
    setLoading(false);
  }, [user]);

  // Subscribe to changes
  useEffect(() => {
    if (!user) return;
    fetchEvents();

    const channel = supabase.channel(`unified_activity_${user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'timeline_events', filter: `user_id=eq.${user.id}` }, (payload) => {
        setEvents(prev => [payload.new, ...prev].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (payload) => {
          const msg = payload.new;
          // Client-side filter for relevant messages since we listen to the whole table for broadcasts
          if (msg.recipient_id === user.id || msg.is_broadcast) {
               setEvents(prev => [normalizeMessage(msg), ...prev].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
               // Optional: trigger a toast here if needed, but DeskContext often handles global notifications
          }
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [user, fetchEvents]);

  const addEvent = useCallback(async (type, title, description = '', metadata = {}) => {
    if (!user) return;
    
    const { error } = await supabase.from('timeline_events').insert({
      user_id: user.id,
      event_type: type,
      title,
      description,
      metadata
    });

    if (error) {
      toast({ title: "Timeline Error", description: "Could not log event.", variant: "destructive" });
      console.error(error);
    }
  }, [user, toast]);

  const getCycleTime = () => {
    // 42 minutes + 8 seconds = 2528 seconds per cycle
    const CYCLE_SECONDS = 2528;
    const now = new Date();
    const secondsInDay = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
    return (secondsInDay / CYCLE_SECONDS).toFixed(4);
  };

  const value = {
    events,
    loading,
    addEvent,
    currentTime,
    getCycleTime
  };

  return <TemporalContext.Provider value={value}>{children}</TemporalContext.Provider>;
};
