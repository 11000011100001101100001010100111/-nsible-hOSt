
import React, { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import LsOutput from '@/components/LsOutput';

const TerminalOutput = ({ events = [] }) => {
  const endOfOutputRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    if (endOfOutputRef.current) {
      endOfOutputRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [events]);

  const renderEvent = (event, index) => {
    if (!event) return null;
    
    switch (event.type) {
      case 'command':
        return (
          <div key={index} className="flex items-center group">
            <span className="text-orange-500 mr-1.5 opacity-80 group-hover:opacity-100 transition-opacity text-sm">@://</span> {/* Reduced margin-right, font size */}
            <p className="text-yellow-100 font-medium text-sm">{event.message}</p> {/* Reduced font size */}
          </div>
        );
      case 'info':
        // Replaced cyan with crimson/red as requested
        return (
          <div key={index} className="my-1 border-l-2 border-red-500/50 pl-1.5"> {/* Reduced margin, padding-left */}
            <p className="font-bold text-red-400 text-sm">{event.title}</p> {/* Reduced font size */}
            <pre className="whitespace-pre-wrap text-red-200/90 font-mono text-xs">{event.message}</pre> {/* Reduced font size */}
          </div>
        );
      case 'success':
        return (
          <div key={index} className="my-1 text-orange-400"> {/* Reduced margin */}
            <p className="font-bold text-orange-500 text-sm">✓ {event.title}</p> {/* Reduced font size */}
            <p className="text-orange-200 text-xs">{event.message}</p> {/* Reduced font size */}
          </div>
        );
      case 'error':
        return (
          <div key={index} className="my-1 text-red-500 bg-red-950/20 px-1 py-0.5 rounded border border-red-900/50"> {/* Reduced margin, padding, rounded */}
            <p className="font-bold text-red-400 text-sm">✕ {event.title}</p> {/* Reduced font size */}
            <p className="text-red-300 text-xs">{event.message}</p> {/* Reduced font size */}
          </div>
        );
      case 'message':
         return (
          <div key={index} className="my-1.5 px-2 py-1 rounded-r-lg bg-gradient-to-r from-fuchsia-900/20 to-transparent border-l-3 border-fuchsia-500"> {/* Reduced margin, padding, border-left */}
            <p className="font-bold text-fuchsia-400 tracking-wide text-xs uppercase mb-0.5">{event.title}</p> {/* Reduced font size, margin-bottom */}
            <p className="text-fuchsia-100 leading-relaxed text-xs">{event.message}</p> {/* Reduced font size */}
          </div>
        );
      case 'ls':
        return <LsOutput key={index} items={event.items} path={event.path} />;
       case 'audio':
        return <div key={index} className="my-1.5 border border-yellow-500/30 p-1.5 rounded bg-yellow-900/10 text-xs">{event.component}</div>; // Reduced margin, padding, font size
      default:
        return <p key={index} className="text-zinc-500 text-[10px]">{JSON.stringify(event)}</p>; // Reduced font size
    }
  };

  return (
    <div ref={containerRef} className="h-full flex-grow overflow-y-auto px-3 py-2 font-mono text-sm space-y-2 custom-scrollbar"> {/* Reduced padding, space-y */}
      {events.map(renderEvent)}
      <div ref={endOfOutputRef} className="h-3" /> {/* Reduced height */}
    </div>
  );
};

export default TerminalOutput;
