
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Minus, Maximize2, ExternalLink, Globe, Lock, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDesk } from '@/contexts/DeskContext';
import { cn } from '@/lib/utils';

const WebFrame = () => {
  const { webFrameState, closeWebFrame, toggleWebFrameMinimize } = useDesk();
  const { url, isOpen, isMinimized, title } = webFrameState;
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  // Reset loading state when URL changes
  useEffect(() => {
    if (isOpen && url) {
      setIsLoading(true);
      setHasError(false);
    }
  }, [url, isOpen]);

  if (!isOpen) return null;

  return (
    <AnimatePresence mode="wait">
      {isMinimized ? (
        // MINIMIZED STATE
        <motion.div
          key="minimized"
          initial={{ y: 80, opacity: 0 }} // Reduced y offset
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }} // Reduced y offset
          className="fixed bottom-0 right-3 z-[70] w-60 bg-black border-t border-l border-r border-blue-900/50 rounded-t-md shadow-lg overflow-hidden cursor-pointer" // Reduced width, rounded
          onClick={toggleWebFrameMinimize}
        >
          <div className="h-7 flex items-center justify-between px-2.5 bg-blue-950/20 hover:bg-blue-900/30 transition-colors"> {/* Reduced height, padding */}
            <div className="flex items-center gap-1.5 overflow-hidden"> {/* Reduced gap */}
               <Globe className="w-2.5 h-2.5 text-blue-400 animate-pulse" /> {/* Reduced icon size */}
               <span className="text-xs font-mono text-blue-100 truncate">{title || 'External Link'}</span> {/* Reduced font size */}
            </div>
            <div className="flex items-center gap-1">
               <Maximize2 className="w-2.5 h-2.5 text-blue-400" /> {/* Reduced icon size */}
            </div>
          </div>
          {/* Progress bar to show it's active */}
          <div className="h-0.5 w-full bg-blue-900/50">
             <div className="h-full bg-blue-500 w-full animate-pulse" />
          </div>
        </motion.div>
      ) : (
        // MAXIMIZED / OPEN STATE
        <motion.div
          key="full"
          initial={{ opacity: 0, scale: 0.98 }} // Reduced scale
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }} // Reduced scale
          transition={{ duration: 0.3 }}
          className="fixed inset-3 z-[60] flex flex-col bg-black/95 border border-blue-900/30 rounded-md shadow-xl backdrop-blur-sm overflow-hidden" // Reduced inset, rounded, shadow
        >
            {/* FRAME HEADER */}
            <div className="flex items-center justify-between px-3 py-1.5 bg-gradient-to-r from-blue-950/30 to-transparent border-b border-blue-900/30 select-none"> {/* Reduced padding */}
                <div className="flex items-center gap-2 overflow-hidden"> {/* Reduced gap */}
                    <div className="p-1 bg-blue-500/10 rounded-sm border border-blue-500/20"> {/* Reduced padding, rounded */}
                        <Globe className="w-3.5 h-3.5 text-blue-400" /> {/* Reduced icon size */}
                    </div>
                    <div className="flex flex-col min-w-0">
                        <span className="text-sm font-bold text-blue-100 font-mono truncate max-w-[250px]">{title}</span> {/* Reduced font size, max-width */}
                        <div className="flex items-center gap-1 text-[9px] text-blue-400/60 font-mono truncate"> {/* Reduced gap, font size */}
                            {url.startsWith('https') ? <Lock className="w-2 h-2" /> : <AlertTriangle className="w-2 h-2 text-yellow-500" />} {/* Reduced icon size */}
                            <span className="truncate">{url}</span>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-1.5"> {/* Reduced gap */}
                    <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 text-blue-400 hover:text-white hover:bg-blue-900/30" // Reduced size
                        onClick={() => {
                            const iframe = document.getElementById('web-frame-content');
                            if(iframe) iframe.src = iframe.src;
                            setIsLoading(true);
                        }}
                        title="Reload Frame"
                    >
                        <RefreshCw className={cn("w-3 h-3", isLoading && "animate-spin")} /> {/* Reduced icon size */}
                    </Button>
                    <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 text-blue-400 hover:text-white hover:bg-blue-900/30" // Reduced size
                        onClick={() => window.open(url, '_blank')}
                        title="Open in new tab"
                    >
                        <ExternalLink className="w-3 h-3" /> {/* Reduced icon size */}
                    </Button>
                    <div className="w-px h-3.5 bg-blue-900/50 mx-1" /> {/* Reduced height */}
                    <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 text-blue-400 hover:text-white hover:bg-blue-900/30" // Reduced size
                        onClick={toggleWebFrameMinimize}
                        title="Minimize"
                    >
                        <Minus className="w-3.5 h-3.5" /> {/* Reduced icon size */}
                    </Button>
                    <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 text-red-400 hover:text-red-200 hover:bg-red-900/20" // Reduced size
                        onClick={closeWebFrame}
                        title="Close Connection"
                    >
                        <X className="w-3.5 h-3.5" /> {/* Reduced icon size */}
                    </Button>
                </div>
            </div>

            {/* FRAME CONTENT */}
            <div className="flex-1 relative bg-white">
                 {isLoading && (
                     <div className="absolute inset-0 z-10 bg-black flex flex-col items-center justify-center space-y-3"> {/* Reduced space-y */}
                         <div className="w-10 h-10 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" /> {/* Reduced size */}
                         <p className="text-blue-400 font-mono text-xs animate-pulse">ESTABLISHING SECURE LINK...</p> {/* Reduced font size */}
                     </div>
                 )}
                 
                 <iframe 
                    id="web-frame-content"
                    src={url}
                    className="w-full h-full border-0"
                    onLoad={() => setIsLoading(false)}
                    onError={() => {
                        setIsLoading(false); 
                        setHasError(true);
                    }}
                    sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
                    title="External Content"
                 />

                 {/* Fallback Overlay if needed (iframe onError doesn't always catch blocked frames, but we try) */}
                 {hasError && (
                     <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center p-5 text-center z-20"> {/* Reduced padding */}
                         <AlertTriangle className="w-10 h-10 text-yellow-500 mb-3" /> {/* Reduced icon size, margin-bottom */}
                         <h3 className="text-white font-bold text-sm mb-1.5">Connection Blocked by Target</h3> {/* Reduced font size, margin-bottom */}
                         <p className="text-gray-400 max-w-sm text-xs mb-5"> {/* Reduced max-width, font size, margin-bottom */}
                             The destination server ({new URL(url).hostname}) refused the embedded connection. This is a common security protocol (X-Frame-Options).
                         </p>
                         <Button onClick={() => window.open(url, '_blank')} className="bg-blue-600 hover:bg-blue-500 text-white h-9 px-3 text-sm"> {/* Reduced height, padding, font size */}
                             <ExternalLink className="w-3.5 h-3.5 mr-1.5" /> {/* Reduced icon size, margin */}
                             Open in Browser Tab
                         </Button>
                     </div>
                 )}
            </div>

            {/* FRAME FOOTER */}
            <div className="h-5 bg-black border-t border-blue-900/30 flex items-center justify-end px-1.5"> {/* Reduced height, padding */}
                <span className="text-[8px] text-blue-600 font-mono">SECURE TUNNEL // TLS 1.3 // PROXY: OFF</span> {/* Reduced font size */}
            </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default WebFrame;
