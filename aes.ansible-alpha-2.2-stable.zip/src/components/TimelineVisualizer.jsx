
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTemporal } from '@/contexts/TemporalContext';
import { Activity, File, MessageSquare, Terminal, Clock, Music, Radio, ChevronRight, ChevronDown, Layers, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTheme } from '@/contexts/ThemeContext';

const EventIcon = ({ type, metadata }) => {
  if (type === 'message') {
      if (metadata?.is_broadcast) return <Radio className="w-4 h-4 text-green-400" />;
      return <MessageSquare className="w-4 h-4 text-emerald-400" />;
  }

  switch (type) {
    case 'file_op': return <File className="w-4 h-4 text-blue-400" />;
    case 'note': return <Terminal className="w-4 h-4 text-yellow-400" />;
    case 'system': return <Activity className="w-4 h-4 text-red-400" />;
    case 'media': return <Music className="w-4 h-4 text-purple-400" />;
    default: return <Activity className="w-4 h-4 text-gray-400" />;
  }
};

const EventContent = ({ event, isCompact = false }) => {
     return (
         <div className="flex items-start gap-2">
            {!isCompact && (
                <div className="mt-0.5 opacity-70 shrink-0">
                    <EventIcon type={event.event_type} metadata={event.metadata} />
                </div>
            )}
            <div className={cn("flex-grow text-white/80 whitespace-pre-wrap leading-relaxed", isCompact ? "text-[10px]" : "text-xs")}>
                {event.description}
            </div>
        </div>
     )
}

const GroupedEventRow = ({ group }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const headEvent = group.events[0];
    const tailEvents = group.events.slice(1);
    const count = group.events.length;
    const isMultiple = count > 1;
    const isMessage = headEvent.event_type === 'message';
    const isSystem = headEvent.event_type === 'system';

    return (
        <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className={cn(
                "relative pl-6 border-l group transition-colors duration-500",
                isMessage ? "border-emerald-500/30" : "border-white/10"
            )}
        >
            {/* Main Dot */}
            <div className={cn(
                "absolute left-[-5px] top-0 w-2.5 h-2.5 rounded-full border transition-all z-10",
                isMessage ? "bg-black border-emerald-500" : "bg-black border-white/30",
                isMultiple && !isExpanded ? "ring-2 ring-white/10 ring-offset-1 ring-offset-black" : ""
            )} />

            <div className="flex flex-col space-y-1 mb-4">
                {/* Header Line */}
                <div className="flex items-center justify-between cursor-pointer" onClick={() => isMultiple && setIsExpanded(!isExpanded)}>
                    <div className="flex items-center gap-2">
                        <span className={cn("font-bold text-xs flex items-center gap-2", 
                            isMessage ? "text-emerald-400" : isSystem ? "text-red-400" : "themed-text-primary"
                        )}>
                            {headEvent.title}
                            {isMessage && headEvent.metadata?.is_broadcast && (
                                <span className="text-[9px] bg-green-900/40 px-1 rounded border border-green-800 text-green-300">BROADCAST</span>
                            )}
                            {isMultiple && (
                                <span className="flex items-center text-[9px] bg-white/10 px-1.5 py-0.5 rounded-full text-white/60 ml-2 border border-white/5 hover:bg-white/20 transition-colors">
                                    {isExpanded ? <ChevronDown className="w-3 h-3 mr-1" /> : <Layers className="w-3 h-3 mr-1" />}
                                    {count}
                                </span>
                            )}
                        </span>
                    </div>
                    <span className="text-[9px] text-white/30 tabular-nums">
                        {new Date(headEvent.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second:'2-digit' })}
                    </span>
                </div>
                
                {/* Head Content */}
                <div className={cn(
                    "p-2 rounded border transition-colors relative",
                    isMessage ? "bg-emerald-950/10 border-emerald-500/20" : "bg-black/20 border-transparent hover:themed-border-secondary/30"
                )}>
                    <EventContent event={headEvent} />
                    
                    {/* Compact Stack Indicator if collapsed */}
                    {isMultiple && !isExpanded && (
                         <div className="absolute -bottom-1 left-4 right-4 h-1 bg-white/5 border-b border-l border-r border-white/5 rounded-b-sm mx-2" />
                    )}
                </div>

                {/* Expanded Tail Events */}
                <AnimatePresence>
                    {isExpanded && tailEvents.length > 0 && (
                        <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden flex flex-col space-y-2 pt-2 border-l border-white/5 ml-2 pl-3"
                        >
                            {tailEvents.map((evt, idx) => (
                                <div key={evt.id || idx} className="relative">
                                    <div className="absolute -left-[17px] top-2 w-1.5 h-1.5 rounded-full bg-white/20" />
                                    <div className="flex justify-between items-baseline mb-1">
                                        <span className="text-[9px] text-white/40">
                                            {new Date(evt.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </span>
                                    </div>
                                    <div className="p-1.5 rounded bg-white/5 border border-white/5 text-[10px] text-white/70">
                                        {evt.description}
                                    </div>
                                </div>
                            ))}
                            
                            <div className="flex justify-center pt-1">
                                <div 
                                    className="cursor-pointer text-[9px] text-white/30 hover:text-white/60 flex items-center gap-1"
                                    onClick={() => setIsExpanded(false)}
                                >
                                    <ChevronDown className="w-3 h-3 rotate-180" /> Collapse Group
                                </div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </motion.div>
    );
};

const TimelineVisualizer = () => {
  const { events, loading, currentTime, getCycleTime } = useTemporal();
  
  // Grouping Logic
  const groupedEvents = useMemo(() => {
      if (!events.length) return [];
      
      const groups = [];
      let currentGroup = null;
      const MAX_GROUP_TIME = 1000 * 60 * 60; // 1 Hour Threshold

      events.forEach((event) => {
          const eventTime = new Date(event.created_at).getTime();
          let groupKey = event.event_type;
          
          if (event.event_type === 'message') {
              groupKey = `msg:${event.title}`; // Group by Sender
          } else if (event.event_type === 'system') {
              groupKey = 'system';
          } else if (event.event_type === 'file_op') {
              groupKey = 'file_op';
          }

          // Check against current group
          // Note: events are sorted DESC (Newest First)
          // currentGroup.lastTime represents the time of the PREVIOUS (Newer) event added to the group
          // We check if current event is within window of the previously added event in this group chain
          
          const timeDiff = currentGroup ? Math.abs(currentGroup.lastTime - eventTime) : 0;

          if (currentGroup && 
              currentGroup.key === groupKey && 
              timeDiff < MAX_GROUP_TIME) {
              
              currentGroup.events.push(event);
              currentGroup.lastTime = eventTime; // Update to chain grouping
          } else {
              currentGroup = {
                  id: `group-${event.id}`,
                  key: groupKey,
                  events: [event],
                  lastTime: eventTime
              };
              groups.push(currentGroup);
          }
      });
      return groups;
  }, [events]);

  if (loading && events.length === 0) {
    return <div className="p-4 text-xs font-mono animate-pulse">Synchronizing unified stream...</div>;
  }

  return (
    <div className="flex flex-col h-full text-xs font-mono overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-2 border-b themed-border-accent bg-black/20 shrink-0">
            <div className="flex items-center space-x-2">
                <Activity className="w-4 h-4 themed-text-primary" />
                <span className="font-bold tracking-wider">UNIFIED LOG</span>
            </div>
            <div className="flex space-x-4 text-[10px] themed-text-secondary">
                <span>LOCAL: {currentTime.toLocaleTimeString()}</span>
                <span>CYCLE: {getCycleTime()}</span>
            </div>
        </div>

        {/* Content */}
        <div className="flex-grow overflow-y-auto p-4 custom-scrollbar">
            {groupedEvents.length === 0 ? (
                <div className="text-center opacity-50 mt-10">No activity recorded.</div>
            ) : (
                <div className="space-y-0">
                    {groupedEvents.map((group) => (
                        <GroupedEventRow key={group.id} group={group} />
                    ))}
                </div>
            )}
            
            {/* End Marker */}
            <div className="relative pl-6 border-l border-white/5 opacity-50 pt-4">
                 <div className="absolute left-[-3px] top-4 w-1.5 h-1.5 rounded-full bg-white/20" />
                 <span className="text-[9px] text-white/20">EVENT HORIZON</span>
            </div>
        </div>
    </div>
  );
};

export default TimelineVisualizer;
