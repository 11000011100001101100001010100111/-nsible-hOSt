
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDesk } from '@/contexts/DeskContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Terminal, Loader2, Signal, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const LiveForum = () => {
  const { user } = useAuth();
  const { addCommandOutput, activeModulations, castVote, userFrequency } = useDesk();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    // Initial fetch
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(`recipient_id.eq.${user.id},is_broadcast.eq.true`)
        .order('created_at', { ascending: false })
        .limit(50);
      
      if (data) setMessages(data.reverse());
    };
    fetchMessages();

    // Subscribe to new messages
    const channel = supabase.channel('public:messages')
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages',
        filter: `recipient_id=eq.${user.id}` 
      }, (payload) => {
        setMessages(prev => [...prev, payload.new]);
      })
      .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `is_broadcast=eq.true`
      }, (payload) => {
          // Avoid duplicates if both filters catch it
          setMessages(prev => {
              if (prev.find(m => m.id === payload.new.id)) return prev;
              return [...prev, payload.new];
          });
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [user.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, activeModulations]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    setIsLoading(true);
    try {
        // Simple global chat for now, sender sends to self but broadcast=true
        // In a real forum, we might have a common room ID
        const { error } = await supabase.from('messages').insert({
            sender_id: user.id,
            sender_username: user.username,
            recipient_id: user.id, // Placeholder
            content: newMessage,
            is_broadcast: true,
            is_read: false
        });
        
        if (error) throw error;
        setNewMessage('');
    } catch (err) {
        addCommandOutput({ type: 'error', title: 'Message Failed', message: err.message });
    } finally {
        setIsLoading(false);
    }
  };

  const handleVote = async (id, val) => {
      try {
          await castVote(id, val);
      } catch(e) {
          addCommandOutput({ type: 'error', title: 'Vote Error', message: e.message });
      }
  };
  
  const isXMF = userFrequency?.startsWith('XMF');

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d] border-l border-white/10 font-mono text-xs"> {/* Reduced font size */}
      <div className="p-2 border-b border-white/10 bg-black/40 backdrop-blur flex justify-between items-center"> {/* Reduced padding */}
        <div className="flex items-center text-red-500 font-bold tracking-wider text-xs"> {/* Reduced font size */}
            <Signal className="w-3.5 h-3.5 mr-1.5 animate-pulse" /> {/* Reduced icon size, margin */}
            LIVE FEED
        </div>
        <div className="text-[8px] text-muted-foreground uppercase"> {/* Reduced font size */}
             {userFrequency || 'NO CARRIER'}
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto p-3 space-y-3" ref={scrollRef}> {/* Reduced padding, space-y */}
        {/* Active Modulations */}
        {activeModulations.length > 0 && (
            <div className="space-y-1.5 mb-3"> {/* Reduced space-y, margin-bottom */}
                {activeModulations.map(mod => {
                    const myVote = mod.votes?.find(v => v.voter_id === user.id);
                    const voteCount = mod.votes?.length || 0;
                    const voteSum = mod.votes?.reduce((acc, v) => acc + v.value, 0) || 0;
                    const average = voteCount > 0 ? (voteSum / voteCount).toFixed(2) : '0.00';
                    const timeLeft = Math.max(0, Math.floor((new Date(mod.expires_at) - new Date()) / 1000));
                    
                    return (
                        <div key={mod.id} className="bg-red-950/20 border border-red-500/30 p-2 rounded relative overflow-hidden"> {/* Reduced padding, rounded */}
                            <div className="absolute top-0 right-0 p-0.5 text-[8px] text-red-500 font-bold bg-black/50">{timeLeft}s REMAINING</div> {/* Reduced padding, font size */}
                            <div className="flex items-start gap-2"> {/* Reduced gap */}
                                <AlertTriangle className="w-6 h-6 text-red-500 shrink-0 mt-0.5" /> {/* Reduced icon size, margin-top */}
                                <div className="flex-grow">
                                    <h4 className="text-red-400 font-bold text-[10px] uppercase mb-0.5">Modulation Request</h4> {/* Reduced font size, margin-bottom */}
                                    <p className="text-gray-300 text-[10px] mb-1">Elevate <span className="text-white font-bold">@{mod.target_username}</span> to XMF band?</p> {/* Reduced font size, margin-bottom */}
                                    
                                    {isXMF ? (
                                        <div className="flex items-center gap-1.5 mt-1"> {/* Reduced gap, margin-top */}
                                            <Button 
                                                size="sm" 
                                                variant={myVote?.value === 1 ? "default" : "outline"} 
                                                className={cn("h-5 px-2 text-[9px]", myVote?.value === 1 ? "bg-green-600 hover:bg-green-700" : "border-green-600/50 text-green-500 hover:bg-green-900/20")} // Reduced height, padding, font size
                                                onClick={() => handleVote(mod.id, 1)}
                                            >
                                                1 (ACCEPT)
                                            </Button>
                                            <Button 
                                                size="sm" 
                                                variant={myVote?.value === 0 ? "default" : "outline"} 
                                                className={cn("h-5 px-2 text-[9px]", myVote?.value === 0 ? "bg-red-600 hover:bg-red-700" : "border-red-600/50 text-red-500 hover:bg-red-900/20")} // Reduced height, padding, font size
                                                onClick={() => handleVote(mod.id, 0)}
                                            >
                                                0 (REJECT)
                                            </Button>
                                            <span className="ml-auto text-[9px] text-gray-500">AVG: {average}</span> {/* Reduced font size */}
                                        </div>
                                    ) : (
                                        <div className="text-[9px] text-gray-500 italic mt-1">XMF Clearance Required to Vote</div> // Reduced font size, margin-top
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={cn("group flex flex-col space-y-0.5 animate-fade-in", msg.sender_username === '@nsible_System' ? "bg-white/5 p-1.5 rounded border-l-2 border-red-500" : "")}> {/* Reduced space-y, padding, rounded */}
            <div className="flex items-baseline space-x-1.5"> {/* Reduced space-x */}
              <span className={cn("text-[10px] font-bold", msg.sender_username === '@nsible_System' ? "text-red-400" : (msg.sender_id === user.id ? "text-blue-400" : "text-green-400"))}> {/* Reduced font size */}
                {msg.sender_username}
              </span>
              <span className="text-[8px] text-muted-foreground">{format(new Date(msg.created_at), 'HH:mm')}</span> {/* Reduced font size */}
            </div>
            <p className="text-gray-300 break-words leading-relaxed text-xs">{msg.content}</p> {/* Reduced font size */}
          </div>
        ))}
      </div>
      
      <form onSubmit={handleSendMessage} className="p-2 border-t border-white/10 bg-black/40 backdrop-blur"> {/* Reduced padding */}
        <div className="flex items-center space-x-1.5"> {/* Reduced space-x */}
          <Input 
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Broadcast message..."
            className="flex-grow bg-black/50 border-white/20 text-white placeholder:text-gray-600 h-8 font-mono text-[10px]" // Reduced height, font size
            disabled={isLoading}
          />
          <Button type="submit" size="icon" variant="ghost" disabled={isLoading} className="h-8 w-8 text-white hover:bg-white/10"> {/* Reduced size */}
            {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />} {/* Reduced icon size */}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default LiveForum;
