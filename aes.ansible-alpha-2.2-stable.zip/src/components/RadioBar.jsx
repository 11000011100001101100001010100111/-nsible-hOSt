
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Square, Volume2, VolumeX, SkipForward, SkipBack, Shuffle, Radio, Signal, Maximize2, Minimize2, Activity, Disc, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useDesk } from '@/contexts/DeskContext';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

const RadioBar = () => {
  const { 
    currentTrack, isPlaying, togglePlay, stopAudio, volume, setVolume, 
    isMuted, setIsMuted, audioProgress, audioDuration, setAudioProgress,
    setAudioDuration, setIsPlaying, seekTo, playNextInQueue, playPreviousInQueue,
    shuffleQueue, audioQueue, isBroadcasting, toggleBroadcast, audioRef, 
    userFrequency, isRadioVisible, setRadioVisible, analyserRef, addCommandOutput,
    handleAudioError
  } = useDesk();
  
  const internalAudioRef = useRef(new Audio());
  const audioContextRef = useRef(null);
  const sourceNodeRef = useRef(null);
  
  // Local state for minimize/maximize
  const [isMinimized, setIsMinimized] = useState(false);
  const [marqueeMessage] = useState("SECURE CHANNEL ESTABLISHED");

  useEffect(() => {
    if (audioRef) audioRef.current = internalAudioRef.current;
  }, [audioRef]);

  // Audio Graph Initialization (Visualizer Connection)
  const initAudioGraph = () => {
      if (!audioContextRef.current && internalAudioRef.current) {
          try {
              const AudioContext = window.AudioContext || window.webkitAudioContext;
              const ctx = new AudioContext();
              const analyser = ctx.createAnalyser();
              analyser.fftSize = 256;
              analyser.smoothingTimeConstant = 0.8;
              
              // Create Source
              const source = ctx.createMediaElementSource(internalAudioRef.current);
              
              // Connect Graph: Source -> Analyser -> Destination
              source.connect(analyser);
              analyser.connect(ctx.destination);
              
              // Store Refs
              audioContextRef.current = ctx;
              sourceNodeRef.current = source;
              
              // Expose to DeskContext for MatrixRain
              if (analyserRef) {
                  analyserRef.current = analyser;
              }
              
              console.log("Audio Graph Initialized: Visualizer Link Established");
          } catch (e) {
              console.warn("Audio Graph Init Failed (Possible CORS or Auto-play policy):", e);
          }
      } else if (audioContextRef.current?.state === 'suspended') {
          audioContextRef.current.resume();
      }
  };

  // Audio Event Listeners
  useEffect(() => {
    const audio = internalAudioRef.current;
    audio.crossOrigin = "anonymous";
    audio.preload = 'auto';

    const handleEnded = () => { setIsPlaying(false); playNextInQueue(); };
    const handleTimeUpdate = () => { if (!audio.paused) setAudioProgress(audio.currentTime); };
    const handleLoadedMetadata = () => {
        if (!isNaN(audio.duration) && audio.duration !== Infinity) {
             setAudioDuration(audio.duration);
        }
        if (isPlaying) {
             initAudioGraph(); // Ensure graph is ready on play
             const playPromise = audio.play();
             if (playPromise !== undefined) {
                 playPromise.catch(e => { 
                     console.warn("Autoplay blocked/failed:", e); 
                     setIsPlaying(false); 
                 });
             }
        }
    };
    const handleError = (e) => { 
        console.error("Audio playback error:", e);
        handleAudioError(`Audio stream failed for current track. Auto-skipping...`);
    };
    const handlePlay = () => {
        initAudioGraph();
    };

    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('error', handleError);

    return () => {
        audio.removeEventListener('ended', handleEnded);
        audio.removeEventListener('timeupdate', handleTimeUpdate);
        audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
        audio.removeEventListener('play', handlePlay);
        audio.removeEventListener('error', handleError);
    };
  }, [setIsPlaying, playNextInQueue, setAudioProgress, setAudioDuration, handleAudioError]);

  // Track Source Management
  useEffect(() => {
    const audio = internalAudioRef.current;
    if (!currentTrack) {
        audio.pause(); 
        audio.removeAttribute('src'); 
        if(!isPlaying) {
             setAudioProgress(0); setAudioDuration(0); 
        }
        return;
    }
    
    if (audio.src !== currentTrack.src && currentTrack.src) {
        audio.src = currentTrack.src;
        
        if (isPlaying) {
             const playPromise = audio.play();
             if (playPromise !== undefined) {
                 playPromise.catch(e => { console.warn("Track switch play failed:", e); setIsPlaying(false); });
             }
        }
    }
  }, [currentTrack]);

  // Play/Pause State Sync
  useEffect(() => {
    const audio = internalAudioRef.current;
    if (currentTrack && audio.src && audio.src !== window.location.href) {
        if (isPlaying && audio.paused) {
             initAudioGraph();
             const playPromise = audio.play();
             if (playPromise !== undefined) {
                 playPromise.catch(error => { console.warn("Sync play failed:", error); setIsPlaying(false); });
             }
        }
        else if (!isPlaying && !audio.paused) {
            audio.pause();
        }
    }
  }, [isPlaying, currentTrack, setIsPlaying]);

  // Volume Sync
  useEffect(() => {
    const audio = internalAudioRef.current;
    if (!isNaN(volume)) audio.volume = Math.max(0, Math.min(1, volume));
    audio.muted = isMuted;
  }, [volume, isMuted]);

  if (!isRadioVisible) return null;

  const handleVolumeChange = (value) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (newVolume > 0 && isMuted) setIsMuted(false);
  };
  const toggleMute = () => setIsMuted(!isMuted);
  const formatTime = (time) => {
    if (isNaN(time) || time === 0) return '00:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };
  
  const handleClose = () => {
      stopAudio();
      setRadioVisible(false);
  };

  const displayTitle = currentTrack ? (currentTrack.title || currentTrack.name) : "NO TAPE LOADED";
  const displayStatus = currentTrack 
        ? (isBroadcasting ? `● LIVE ON ${userFrequency || 'UNK-FREQ'}` : `Queue: ${audioQueue.length} Tracks`) 
        : `${audioQueue.length} Tracks Queued`;
  
  const bitrate = currentTrack?.bitrate || "---kbps";
  const marqueeContent = `TRACK: ${displayTitle.toUpperCase()} /// STATUS: ${isBroadcasting ? "BROADCASTING" : "LOCAL"} /// BITRATE: ${bitrate} /// MSG: ${marqueeMessage} /// PRESS MAX TO EXPAND`.trim();

  return (
    <AnimatePresence mode="wait">
      {isMinimized ? (
        <motion.div 
          key="minimized"
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="fixed bottom-0 left-0 right-0 z-[60] h-7 bg-black/90 backdrop-blur border-t border-red-900/50 shadow-[0_-3px_15px_rgba(0,0,0,0.5)]"
        >
          <div className="w-full h-full flex items-center overflow-hidden relative group cursor-pointer" onClick={() => setIsMinimized(false)}>
            <div className="absolute left-0 top-0 bottom-0 w-7 bg-black/50 z-10 flex items-center justify-center border-r border-red-900/30">
              <Activity className={cn("w-3.5 h-3.5", isPlaying ? "text-red-500 animate-pulse" : "text-gray-600")} />
            </div>
            
            <div className="flex-1 overflow-hidden relative whitespace-nowrap mask-linear-fade">
              <motion.div 
                className="inline-block text-[9px] font-mono text-red-400/90 px-3 pt-0.5"
                animate={{ x: ["100%", "-100%"] }} 
                transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
              >
                {marqueeContent}
              </motion.div>
            </div>

            <div className="absolute right-0 top-0 bottom-0 bg-black/90 z-10 flex items-center gap-0.5 px-1.5 border-l border-red-900/30">
              <Button size="icon" variant="ghost" className="h-5 w-5 text-red-500 hover:text-white hover:bg-red-900/20" onClick={(e) => { e.stopPropagation(); togglePlay(); }}>
                {isPlaying ? <Pause size={9} fill="currentColor" /> : <Play size={9} fill="currentColor" />}
              </Button>
              <Button size="icon" variant="ghost" className="h-5 w-5 text-muted-foreground hover:text-white" onClick={(e) => { e.stopPropagation(); setIsMinimized(false); }}>
                <Maximize2 size={9} />
              </Button>
              <Button size="icon" variant="ghost" className="h-5 w-5 text-muted-foreground hover:text-red-500" onClick={(e) => { e.stopPropagation(); handleClose(); }}>
                <X size={9} />
              </Button>
            </div>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="maximized"
          initial={{ y: 150, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 150, opacity: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="fixed bottom-0 left-0 right-0 z-[60] pointer-events-none"
        >
          {/* Robust full-width bar with constraints and responsive padding */}
          <div className="w-full bg-black/90 backdrop-blur-xl border-t border-red-900/30 shadow-[0_-5px_20px_rgba(0,0,0,0.7)] overflow-hidden pointer-events-auto ring-1 ring-white/5 relative group pb-safe-area">
            
            <div className="absolute top-1.5 right-1.5 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center gap-0.5">
              <Button 
                size="icon" 
                variant="ghost" 
                className="h-5 w-5 text-muted-foreground hover:text-white bg-black/50 rounded-full" 
                onClick={() => setIsMinimized(true)}
              >
                <Minimize2 size={10} />
              </Button>
              <Button 
                size="icon" 
                variant="ghost" 
                className="h-5 w-5 text-muted-foreground hover:text-red-500 bg-black/50 rounded-full" 
                onClick={handleClose}
              >
                <X size={10} />
              </Button>
            </div>

            <div className="px-3 pt-2 pb-0.5">
                <div className="flex items-center justify-between text-[8px] font-mono text-muted-foreground mb-0.5">
                    <span>{formatTime(audioProgress)}</span>
                    <span>{formatTime(audioDuration)}</span>
                </div>
                <Slider 
                    value={[audioProgress]} 
                    max={audioDuration || 100} 
                    step={1} 
                    disabled={!currentTrack} 
                    onValueChange={(value) => seekTo(value[0])} 
                    className="w-full h-1 cursor-pointer"
                />
            </div>

            <div className="flex items-center justify-between p-3 pt-1.5 gap-2">
              
              <div className="flex items-center space-x-2 w-1/3 overflow-hidden">
                <div className="h-8 w-8 rounded-md bg-gradient-to-br from-red-950 to-black flex items-center justify-center border border-red-900/30 flex-shrink-0 relative shadow-inner">
                  {currentTrack ? (
                     <Radio className={cn("w-4 h-4 text-red-500", isPlaying && "animate-pulse")} />
                  ) : (
                     <Disc className="w-4 h-4 text-gray-700" />
                  )}
                  {isBroadcasting && (
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full animate-ping shadow-[0_0_8px_#ef4444]" />
                  )}
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-sm font-bold text-white truncate font-mono tracking-tight">{displayTitle}</span>
                  <div className="flex items-center gap-1.5">
                    <span className={cn("text-[9px] uppercase tracking-wider truncate", isBroadcasting ? "text-red-400 font-bold animate-pulse" : "text-gray-500")}>
                        {displayStatus}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center space-x-1.5 flex-1 min-w-0">
                <Button onClick={shuffleQueue} size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:text-white hidden sm:flex" title="Shuffle">
                  <Shuffle size={12} />
                </Button>
                <Button onClick={playPreviousInQueue} size="icon" variant="ghost" className="h-8 w-8 text-white hover:bg-white/10 rounded-full">
                  <SkipBack size={16} />
                </Button>
                <Button 
                    onClick={togglePlay} 
                    size="icon" 
                    className={cn(
                        "h-10 w-10 shrink-0 rounded-full text-white shadow-[0_0_15px_rgba(220,20,60,0.4)] border border-red-400/50 transition-all active:scale-95",
                        isPlaying ? "bg-red-600 hover:bg-red-500" : "bg-red-950 hover:bg-red-900"
                    )}
                >
                  {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                </Button>
                <Button onClick={playNextInQueue} size="icon" variant="ghost" className="h-8 w-8 text-white hover:bg-white/10 rounded-full">
                  <SkipForward size={16} />
                </Button>
                <Button onClick={stopAudio} size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:text-red-400 hidden sm:flex" title="Stop">
                  <Square size={12} fill="currentColor" />
                </Button>
              </div>

              <div className="flex items-center space-x-2 w-1/3 justify-end overflow-hidden">
                <Button 
                    onClick={toggleBroadcast} 
                    size="sm" 
                    variant="ghost" 
                    disabled={!currentTrack} 
                    className={cn(
                        "h-7 px-1.5 text-[9px] transition-all border border-transparent hidden sm:flex",
                        isBroadcasting 
                            ? "bg-red-950/50 text-red-500 border-red-900/50 shadow-[0_0_10px_rgba(220,20,60,0.2)]"
                            : "text-muted-foreground hover:text-white hover:bg-white/5"
                    )} 
                    title={isBroadcasting ? "Stop Broadcast" : "Start Broadcast"}
                >
                  <Signal size={12} className={cn("mr-1", isBroadcasting && "animate-pulse")} />
                  <span className="font-mono">{isBroadcasting ? "ON AIR" : "TX"}</span>
                </Button>
                
                <div className="w-px h-6 bg-white/10 mx-0.5 hidden sm:block" />
                
                <div className="flex items-center gap-1.5 group/vol">
                    <Button onClick={toggleMute} size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:text-white shrink-0">
                    {isMuted || volume === 0 ? <VolumeX size={14} /> : <Volume2 size={14} />}
                    </Button>
                    <div className="w-16 transition-all opacity-50 group-hover/vol:opacity-100 hidden md:block">
                    <Slider value={[isMuted ? 0 : volume]} max={1} step={0.01} onValueChange={handleVolumeChange} className="w-full" />
                    </div>
                </div>
              </div>
            </div>
            {/* Safe area padding for bottom swipe bars on mobile */}
            <div className="h-1 w-full" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default RadioBar;
