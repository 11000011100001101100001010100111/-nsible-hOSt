
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { X } from 'lucide-react';

const LoginModal = ({ isOpen, setIsOpen }) => {
  const [isLoginView, setIsLoginView] = useState(true);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-end z-50 pr-12" // Reduced padding-right
          onClick={() => setIsOpen(false)}
        >
          <motion.div
            key={isLoginView ? 'login' : 'register'}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="relative bg-black/80 border themed-border-primary/50 rounded-md px-6 py-5 w-80" // Reduced padding, width, rounded
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={() => setIsOpen(false)} variant="ghost" className="absolute top-1.5 right-1.5 p-1 h-auto z-10 text-gray-400 hover:themed-text-accent"><X className="w-5 h-5" /></Button> {/* Reduced top/right, padding, icon size */}
            {isLoginView ? <LoginForm setIsLoginView={setIsLoginView} setIsOpen={setIsOpen} /> : <RequestAccountForm setIsLoginView={setIsLoginView} />}
            
            <div className="mt-5 text-center"> {/* Reduced margin-top */}
              <div className="themed-text-primary terminal-text text-xs">
                <span className="typing-cursor">_</span> Secure connection established
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

const LoginForm = ({ setIsLoginView, setIsOpen }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast({ title: "Error", description: "Please enter email and password", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      toast({ title: "Login Failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Access granted. Welcome back." });
      setIsOpen(false);
    }
    setIsLoading(false);
  };

  return (
    <>
      <div className="text-center mb-6"> {/* Reduced margin-bottom */}
        <h1 className="text-2xl font-bold terminal-text themed-text-primary mb-1.5">DIRECTORY ACCESS</h1> {/* Reduced font size, margin-bottom */}
        <p className="themed-text-secondary terminal-text text-sm">Enter credentials to access your allocated space</p>
      </div>
      <form onSubmit={handleLogin} className="space-y-4"> {/* Reduced space-y */}
        <div className="space-y-3"> {/* Reduced space-y */}
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-black/50 themed-border-secondary/50 themed-text-accent terminal-text focus:ring-themed-accent focus:themed-border-accent text-sm h-10" placeholder="EMAIL" disabled={isLoading} /> {/* Reduced height, font size */}
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-black/50 themed-border-secondary/50 themed-text-accent terminal-text focus:ring-themed-accent focus:themed-border-accent text-sm h-10" placeholder="PASSWORD" disabled={isLoading} /> {/* Reduced height, font size */}
        </div>
        <div className="space-y-3"> {/* Reduced space-y */}
          <Button type="submit" disabled={isLoading} className="w-full h-10 bg-black/75 hover:themed-bg-primary text-white font-semibold terminal-text border themed-border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-[hsl(var(--theme-primary))] text-sm"> {/* Reduced height, font size */}
            {isLoading ? 'ACCESSING...' : 'ACCESS DIRECTORY'}
          </Button>
          <Button type="button" onClick={() => setIsLoginView(false)} variant="outline" className="w-full h-10 bg-transparent themed-border-primary/50 themed-text-primary hover:themed-bg-primary/50 hover:text-white terminal-text text-sm"> {/* Reduced height, font size */}
            REQUEST ACCOUNT
          </Button>
        </div>
      </form>
    </>
  );
};

const RequestAccountForm = ({ setIsLoginView }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleRequest = async (e) => {
    e.preventDefault();
    if (!username.trim() || !email.trim() || !password.trim()) {
      toast({ title: "Error", description: "All fields are required.", variant: "destructive" });
      return;
    }
    setIsLoading(true);

    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username: username.toLowerCase().replace(/[^a-z0-9]/g, ''),
        }
      }
    });

    if (signUpError) {
      toast({ title: "Request Failed", description: signUpError.message, variant: "destructive" });
    } else if (signUpData.user) {
      toast({ title: "Request Sent", description: "Your account request has been submitted for approval.", duration: 9000 });
      setIsLoginView(true);
    }
    
    setIsLoading(false);
  };

  return (
    <>
      <div className="text-center mb-6"> {/* Reduced margin-bottom */}
        <h1 className="text-2xl font-bold terminal-text themed-text-primary mb-1.5">REQUEST ACCESS</h1> {/* Reduced font size, margin-bottom */}
        <p className="themed-text-secondary terminal-text text-sm">Submit a request for a new directory space</p>
      </div>
      <form onSubmit={handleRequest} className="space-y-4"> {/* Reduced space-y */}
        <div className="space-y-3"> {/* Reduced space-y */}
          <Input value={username} onChange={(e) => setUsername(e.target.value)} className="bg-black/50 themed-border-secondary/50 themed-text-accent terminal-text focus:ring-themed-accent focus:themed-border-accent text-sm h-10" placeholder="USERNAME" disabled={isLoading} /> {/* Reduced height, font size */}
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-black/50 themed-border-secondary/50 themed-text-accent terminal-text focus:ring-themed-accent focus:themed-border-accent text-sm h-10" placeholder="EMAIL" disabled={isLoading} /> {/* Reduced height, font size */}
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-black/50 themed-border-secondary/50 themed-text-accent terminal-text focus:ring-themed-accent focus:themed-border-accent text-sm h-10" placeholder="PASSWORD" disabled={isLoading} /> {/* Reduced height, font size */}
        </div>
        <div className="space-y-3"> {/* Reduced space-y */}
          <Button type="submit" disabled={isLoading} className="w-full h-10 themed-bg-primary/75 hover:themed-bg-primary text-white font-semibold terminal-text border themed-border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-[hsl(var(--theme-primary))] text-sm"> {/* Reduced height, font size */}
            {isLoading ? 'SUBMITTING...' : 'SUBMIT REQUEST'}
          </Button>
          <Button type="button" onClick={() => setIsLoginView(true)} variant="outline" className="w-full h-10 bg-transparent themed-border-primary/50 themed-text-primary hover:themed-bg-primary/50 hover:text-white terminal-text text-sm"> {/* Reduced height, font size */}
            BACK TO LOGIN
          </Button>
        </div>
      </form>
    </>
  );
};

export default LoginModal;
