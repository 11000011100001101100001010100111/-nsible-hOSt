
import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

const CYCLE_SECONDS = 42 * 60 + 8; // 2528 seconds

const CycleClock = () => {
  const [cycleTime, setCycleTime] = useState('00:00.00');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Calculate seconds since start of current cycle period
      // For simplicity, we'll base it on seconds since epoch modulo cycle length
      // This ensures all users are synchronized to the same global "cycle"
      const totalSeconds = Math.floor(now.getTime() / 1000);
      const secondsInCycle = totalSeconds % CYCLE_SECONDS;
      
      // Format as MM:SS.cc (centiseconds for digital feel)
      const minutes = Math.floor(secondsInCycle / 60);
      const seconds = Math.floor(secondsInCycle % 60);
      const centis = Math.floor((now.getMilliseconds() / 10)); // 0-99

      const pad = (n) => n.toString().padStart(2, '0');
      setCycleTime(`${pad(minutes)}:${pad(seconds)}.${pad(centis)}`);
    };

    const interval = setInterval(updateTime, 50); // Update frequently for smooth centiseconds
    updateTime();

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center mx-1 font-mono leading-none select-none">
       <div className="text-[7px] text-red-500/50 uppercase tracking-widest mb-[1px]">Cycle Time</div>
       <div className="text-red-500 font-bold text-sm tabular-nums tracking-tight drop-shadow-[0_0_2px_rgba(239,68,68,0.5)]">
         {cycleTime}
       </div>
    </div>
  );
};

export default CycleClock;
