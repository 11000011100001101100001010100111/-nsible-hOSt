
import React, { useRef, useEffect } from 'react';
import { useDesk } from '@/contexts/DeskContext';

const MatrixRain = ({ color = '#ff0000' }) => {
  const canvasRef = useRef(null);
  const { isPlaying, analyserRef } = useDesk();
  const dataArrayRef = useRef(new Uint8Array(128)); // Small buffer for average calculation

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()_+-=[]{}|;:,.<>?/'.split('');
    const fontSize = 14; 
    const columns = Math.floor(canvas.width / fontSize);
    const drops = Array(columns).fill(1);

    const draw = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Default: Silver/Grey
      let r = 128;
      let g = 128;
      let b = 128;
      
      if (isPlaying && analyserRef.current) {
          try {
             const analyser = analyserRef.current;
             // Re-allocate if fftSize changed
             if (dataArrayRef.current.length !== analyser.frequencyBinCount) {
                  dataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);
             }
             
             analyser.getByteFrequencyData(dataArrayRef.current);
             
             // Calculate average intensity focused on bass/mids
             let sum = 0;
             const meaningfulBins = Math.floor(dataArrayRef.current.length / 2);
             for (let i = 0; i < meaningfulBins; i++) {
                 sum += dataArrayRef.current[i];
             }
             const average = sum / meaningfulBins;
             const intensity = Math.min(1, average / 128); // Normalize 0-1, sensitive
             
             // Interpolate from Silver (128,128,128) to Crimson (220, 20, 60)
             // R: 128 -> 220 (+92)
             // G: 128 -> 20  (-108)
             // B: 128 -> 60  (-68)
             
             r = Math.floor(128 + (92 * intensity));
             g = Math.floor(128 - (108 * intensity));
             b = Math.floor(128 - (68 * intensity));

          } catch (e) {
              // Fallback to silver
          }
      }
      
      const dynamicColor = `rgba(${r}, ${g}, ${b}, 0.8)`;
      ctx.fillStyle = dynamicColor;
      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = characters[Math.floor(Math.random() * characters.length)];
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    };

    const animate = () => {
      draw();
      animationFrameId = window.requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, analyserRef]);

  return <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full z-0" />;
};

export default MatrixRain;
