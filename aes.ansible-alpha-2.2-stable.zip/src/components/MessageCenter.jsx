
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { History, Clock, Send, X, MoreHorizontal, Filter, ZoomIn, ZoomOut } from 'lucide-react';
import { useDesk } from '@/contexts/DeskContext';
import { useTheme } from '@/contexts/ThemeContext';
import SwipeableMessage from './SwipeableMessage';
import { AnimatePresence, motion } from 'framer-motion';

const CYCLE_SECONDS = 42 * 60 + 8;
const COLLECTION_FILE = 'collection.log';

const b64EncodeUnicode = (str) => {
  return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (match, p1) => {
    return String.fromCharCode('0x' + p1);
  }));
};

const formatTime = (date, format) => {
  if (!date) return '';
  const d = new Date(date);
  if (format === '12h') {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  }
  if (format === 'cycle') {
    const secondsInDay = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
    const cycles = (secondsInDay / CYCLE_SECONDS).toFixed(3);
    return `${cycles}c`;
  }
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
};

const RealtimeClock = () => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const timerId = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timerId);
  }, []);
  return (
    <div className="relative top-[9px]">
      <div className="text-[9px] font-mono themed-text-primary bg-black/50 border-2 themed-border-primary rounded px-1.5 py-0.5 whitespace-nowrap">
        {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
      </div>
    </div>
  );
};

const MessageCenter = ({ user }) => {
  const [messages, setMessages] = useState([]);
  const [collectedMessages, setCollectedMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Interactive State
  const [expandedId, setExpandedId] = useState(null);
  const [replyingTo, setReplyingTo] = useState(null); // Message Object
  const [replyContent, setReplyContent] = useState('');
  const [contextMenu, setContextMenu] = useState(null); // { x, y, msg }
  const [scale, setScale] = useState(1);
  
  const { timelinePosition, setTimelinePosition, fileSystem, updateFileSystem, addCommandOutput } = useDesk();
  const [timeFilter, setTimeFilter] = useState(timelinePosition === 100 ? [24] : [Math.ceil(24 * (timelinePosition / 100))]);
  const { toast } = useToast();
  const { theme } = useTheme();
  
  const scrollRef = useRef(null);

  // --- Pinch Detection ---
  useEffect(() => {
    const ref = scrollRef.current;
    if (!ref) return;

    let startDist = 0;
    let startScale = 1;

    const handleTouchStart = (e) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        startDist = Math.hypot(
          e.touches[0].pageX - e.touches[1].pageX,
          e.touches[0].pageY - e.touches[1].pageY
        );
        startScale = scale;
      }
    };

    const handleTouchMove = (e) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const dist = Math.hypot(
          e.touches[0].pageX - e.touches[1].pageX,
          e.touches[0].pageY - e.touches[1].pageY
        );
        const newScale = startScale * (dist / startDist);
        setScale(Math.min(Math.max(0.8, newScale), 1.5));
      }
    };

    ref.addEventListener('touchstart', handleTouchStart, { passive: false });
    ref.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      ref.removeEventListener('touchstart', handleTouchStart);
      ref.removeEventListener('touchmove', handleTouchMove);
    };
  }, [scale]);

  // --- Data Fetching ---
  const fetchCollectionLog = useCallback(() => {
    if (!fileSystem) return [];
    const documents = fileSystem['documents']?.content;
    if (!documents) return [];
    const encodedFileName = b64EncodeUnicode(COLLECTION_FILE);
    const collectionFile = documents[encodedFileName];
    if (collectionFile && collectionFile.content) {
      return collectionFile.content.trim().split('\n').map((line, index) => {
        const match = line.match(/\[(.*?)\] <(.*?)>: (.*)/);
        if (match) {
          return {
            id: `collected-${index}`,
            created_at: match[1],
            sender_username: match[2],
            content: match[3],
            is_collected: true,
          };
        }
        return null;
      }).filter(Boolean);
    }
    return [];
  }, [fileSystem]);

  const fetchMessages = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const now = new Date();
    const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();

    const { data: dbMessages, error: msgError } = await supabase
      .from('messages')
      .select('*')
      .or(`recipient_id.eq.${user.id},is_broadcast.eq.true`)
      .gte('created_at', twentyFourHoursAgo)
      .order('created_at', { ascending: false });
    
    if (msgError) toast({ title: "Error", description: "Could not fetch messages.", variant: "destructive" });

    let requestMessages = [];
    if (user.profile?.is_approved) {
        const { data: pendingUsers } = await supabase
            .from('users')
            .select('*')
            .eq('is_approved', false)
            .order('requested_at', { ascending: false });
            
        if (pendingUsers) {
            requestMessages = pendingUsers.map(u => ({
                id: `req-${u.id}`,
                sender_username: `non.usr.req/${u.username}`,
                content: `Signal detected. Access Request pending authorization.`,
                created_at: u.requested_at,
                is_request: true,
                request_user_id: u.id,
                request_username: u.username,
                is_read: false
            }));
        }
    }

    setMessages([...requestMessages, ...(dbMessages || [])]);
    setLoading(false);
  }, [user, toast]);

  useEffect(() => {
    if (!user) return;
    fetchMessages();
    const msgChannel = supabase.channel('public:messages')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => fetchMessages())
      .subscribe();
    const usersChannel = supabase.channel('public:users:requests')
       .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, () => fetchMessages())
       .subscribe();
    return () => {
      supabase.removeChannel(msgChannel);
      supabase.removeChannel(usersChannel);
    };
  }, [fetchMessages, user]);

  useEffect(() => {
    setCollectedMessages(fetchCollectionLog());
  }, [fileSystem, fetchCollectionLog]);

  // --- Actions ---
  const handleSliderChange = (value) => {
    const hours = Math.ceil(24 * (value[0] / 100));
    setTimeFilter([hours]);
    setTimelinePosition(value[0]);
  };

  const toggleReadStatus = async (msg) => {
    if (msg.is_collected || msg.is_request) return;
    const { error } = await supabase.from('messages').update({ is_read: !msg.is_read }).eq('id', msg.id);
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    setContextMenu(null);
  };

  const deleteMessage = async (msg) => {
    if (msg.is_collected) return;
    if (msg.is_request) {
        // Use Ban for request deletion
        handleBan(msg);
        return;
    }
    const { error } = await supabase.from('messages').delete().eq('id', msg.id);
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    setContextMenu(null);
  };
  
  const collectMessage = async (msg) => {
    if (!fileSystem) return;
    if (msg.is_collected) {
        toast({ title: "Already Saved", description: "Message is in archives." });
        return;
    }

    const collectionEntry = `[${msg.created_at}] <${msg.sender_username}>: ${msg.content}\n`;
    const encodedFileName = b64EncodeUnicode(COLLECTION_FILE);
    
    try {
        // Ensure documents folder exists. 
        if (!fileSystem['documents']) {
             await updateFileSystem('Init Archives', {
                 key: 'documents',
                 value: { type: 'folder', content: {} },
                 path: [],
                 silent: true
             });
        }

        await updateFileSystem(`Collected message`, {
            key: encodedFileName,
            path: ['documents'],
            value: { type: 'file', content: collectionEntry },
            append: true
        });

        toast({ title: "Archived", description: "Message saved to collection.log" });
        setContextMenu(null);
    } catch (error) {
        console.error("Archive error:", error);
        toast({ title: "Archive Failed", description: error.message, variant: "destructive" });
    }
  };

  const handlePermit = async (msg) => {
      const { error } = await supabase.from('users').update({ is_approved: true, approved_at: new Date() }).eq('id', msg.request_user_id);
      if (!error) addCommandOutput({ type: 'success', title: 'ArchX', message: `Permit granted for ${msg.request_username}` });
  };

  const handleBan = async (msg) => {
      const { error } = await supabase.from('users').delete().eq('id', msg.request_user_id);
      if (!error) addCommandOutput({ type: 'success', title: 'ArchX', message: `Request terminated for ${msg.request_username}` });
  };

  const sendReply = async () => {
      if (!replyContent.trim() || !replyingTo) return;

      // Intercept replies to System or Requests
      if (replyingTo.sender_username.includes('System') || replyingTo.sender_username.includes('non.usr.req') || !replyingTo.sender_id) {
          const systemResponses = [
              "Input buffer received. Analysis complete.",
              "Protocol acknowledged. No further action required.",
              "Echo reflected from the void.",
              "System maintains constant vigilance.",
              "Query logged in infinite storage.",
              "Direct interface response: ACK.",
              "Simulation parameters updated.",
              "Manual override not available for this channel."
          ];
          const responseText = systemResponses[Math.floor(Math.random() * systemResponses.length)];

          const { error } = await supabase.from('messages').insert({
              sender_id: user.id, // We use user.id to allow RLS insertion, but label it as System
              sender_username: '@nsible_System',
              recipient_id: user.id, // Send to self so it appears in inbox
              content: `[RE: ${replyContent.substring(0, 15)}...] ${responseText}`,
              is_broadcast: false,
              is_read: false
          });

          if (error) {
             toast({ title: "System Error", description: "Voice module failed.", variant: "destructive" });
          } else {
             toast({ title: "System", description: "Input processed." });
             setReplyingTo(null);
             setReplyContent('');
          }
          return;
      }
      
      const { error } = await supabase.from('messages').insert({
          sender_id: user.id,
          sender_username: user.username,
          recipient_id: replyingTo.sender_id, // Assuming sender_id exists on original message
          content: replyContent,
          is_broadcast: false,
          is_read: false
      });
      
      if (error) {
          toast({ title: "Failed", description: error.message, variant: "destructive" });
      } else {
          toast({ title: "Sent", description: "Reply transmitted." });
          setReplyingTo(null);
          setReplyContent('');
      }
  };

  // --- Grouping & Filtering ---
  const allMessages = useMemo(() => {
      const now = new Date();
      const filterMillis = timeFilter[0] * 60 * 60 * 1000;
      const cutoffDate = new Date(now.getTime() - filterMillis);
      
      const filtered = [...messages, ...collectedMessages].filter(msg => new Date(msg.created_at) >= cutoffDate);
      // Sort by date DESC
      return filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }, [messages, collectedMessages, timeFilter]);

  // --- Context Menu ---
  const handleContextMenu = (e, msg) => {
      e.preventDefault();
      // Calculate position to keep within bounds
      const x = Math.min(e.clientX, window.innerWidth - 150);
      const y = Math.min(e.clientY, window.innerHeight - 200);
      setContextMenu({ x, y, msg });
  };

  // --- Render ---
  if (!user) return <div className="p-3 text-xs">Authenticating...</div>;

  return (
    <div className="flex flex-col h-full text-xs relative" onClick={() => setContextMenu(null)}>
      {/* Header Controls */}
      <div className="flex justify-between items-center mb-1 flex-shrink-0 px-2 py-1 bg-black/20 border-b themed-border-accent/20">
        <h2 className="text-lg font-bold flex items-center mr-3"><History className="mr-2 w-4 h-4" />COMMS</h2>
        <div className="flex items-center space-x-2 flex-grow">
          <Clock className="w-3 h-3 themed-text-secondary" />
          <Slider
            value={[timelinePosition]}
            max={100}
            step={1}
            onValueChange={handleSliderChange}
            className="w-24 h-1"
            customThumb={<RealtimeClock />}
          />
          <div className="flex items-center gap-1 ml-auto">
             <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setScale(s => Math.min(s + 0.1, 1.5))}><ZoomIn className="w-3 h-3" /></Button>
             <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setScale(s => Math.max(s - 0.1, 0.8))}><ZoomOut className="w-3 h-3" /></Button>
          </div>
        </div>
      </div>

      {/* Message List */}
      <div 
        ref={scrollRef}
        className="flex-grow overflow-y-auto p-2 custom-scrollbar touch-pan-y"
        style={{ fontSize: `${12 * scale}px` }}
      >
        {allMessages.length === 0 && <div className="text-center opacity-50 mt-10">No signals detected.</div>}
        
        {allMessages.map(msg => (
             <SwipeableMessage 
                key={msg.id} 
                msg={msg}
                onReply={(m) => setReplyingTo(m)}
                onDelete={deleteMessage}
                onArchive={collectMessage}
                onToggleRead={toggleReadStatus}
                onPermit={handlePermit}
                onBan={handleBan}
                isExpanded={expandedId === msg.id}
                onToggleExpand={(id) => setExpandedId(expandedId === id ? null : id)}
                formatTime={formatTime}
                themeTimeFormat={theme.timeFormat}
                onContextMenu={handleContextMenu}
             />
        ))}
      </div>

      {/* Inline Composer Overlay */}
      <AnimatePresence>
        {replyingTo && (
            <motion.div 
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                className="absolute bottom-0 left-0 right-0 bg-black/90 border-t themed-border-accent p-3 z-50 shadow-2xl"
            >
                <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-blue-400">Replying to: {replyingTo.sender_username}</span>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setReplyingTo(null)}><X className="w-4 h-4" /></Button>
                </div>
                <Textarea 
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    placeholder="Transmission content..."
                    className="min-h-[80px] bg-zinc-900 border-zinc-700 mb-2 text-xs"
                    autoFocus
                />
                <div className="flex justify-end">
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-500 text-white gap-2" onClick={sendReply}>
                        <Send className="w-3 h-3" /> TRANSMIT
                    </Button>
                </div>
            </motion.div>
        )}
      </AnimatePresence>

      {/* Context Menu Overlay */}
      {contextMenu && (
          <div 
            className="fixed z-50 w-40 bg-zinc-900 border border-zinc-700 rounded shadow-xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200"
            style={{ top: contextMenu.y, left: contextMenu.x }}
            onClick={(e) => e.stopPropagation()}
          >
              <div className="px-3 py-2 border-b border-zinc-800 text-[10px] text-zinc-500 font-bold bg-zinc-950">
                  ACTIONS
              </div>
              <button className="px-3 py-2 text-left hover:bg-zinc-800 text-xs flex items-center gap-2" onClick={() => { setReplyingTo(contextMenu.msg); setContextMenu(null); }}>
                  <Send className="w-3 h-3" /> Reply
              </button>
              <button className="px-3 py-2 text-left hover:bg-zinc-800 text-xs flex items-center gap-2" onClick={() => toggleReadStatus(contextMenu.msg)}>
                  {contextMenu.msg.is_read ? <History className="w-3 h-3" /> : <History className="w-3 h-3" />} 
                  {contextMenu.msg.is_read ? 'Mark Unread' : 'Mark Read'}
              </button>
              <button className="px-3 py-2 text-left hover:bg-zinc-800 text-xs flex items-center gap-2 text-amber-500" onClick={() => collectMessage(contextMenu.msg)}>
                  <MoreHorizontal className="w-3 h-3" /> Archive
              </button>
              <button className="px-3 py-2 text-left hover:bg-red-900/20 text-xs flex items-center gap-2 text-red-500" onClick={() => deleteMessage(contextMenu.msg)}>
                  <X className="w-3 h-3" /> Delete
              </button>
          </div>
      )}
    </div>
  );
};

export default MessageCenter;
