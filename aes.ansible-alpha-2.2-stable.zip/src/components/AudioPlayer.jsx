
import React from 'react';
import { Play, Pause, StopCircle, Volume2, VolumeX, SkipForward, SkipBack } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useDesk } from '@/contexts/DeskContext';
import { cn } from '@/lib/utils';

// This component now acts as a controller for the global audio state
const AudioPlayer = () => {
  const { 
    currentTrack, 
    isPlaying, 
    togglePlay, 
    stopAudio, 
    volume, 
    setVolume, 
    isMuted, 
    setIsMuted,
    audioProgress,
    audioDuration,
    seekTo,
    playNextInQueue,
    playPreviousInQueue,
    audioQueue
  } = useDesk();

  if (!currentTrack) return null;

  const handleVolumeChange = (value) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (newVolume > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const formatTime = (time) => {
    if (isNaN(time) || time === 0) return '00:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  return (
    <div className="bg-black/80 border-t themed-border-accent px-2 py-1 terminal-text flex flex-col space-y-1 backdrop-blur-md"> {/* Reduced padding, space-y */}
       {/* Progress Bar */}
       <div className="flex items-center space-x-1 text-[9px] themed-text-secondary px-0.5"> {/* Reduced space-x, font size, px */}
          <span className="w-7 text-right font-mono">{formatTime(audioProgress)}</span> {/* Reduced width */}
          <Slider
            value={[audioProgress]}
            max={audioDuration || 100}
            step={1}
            onValueChange={(value) => seekTo(value[0])}
            className="w-full flex-grow h-1" // Reduced height
          />
          <span className="w-7 font-mono">{formatTime(audioDuration)}</span> {/* Reduced width */}
       </div>

      <div className="flex items-center justify-between px-0.5"> {/* Reduced px */}
          {/* Track Info */}
          <div className="flex flex-col min-w-0 max-w-[120px] sm:max-w-[150px]"> {/* Reduced max-width */}
             <span className="text-xs font-bold themed-text-primary truncate" title={currentTrack.title}>
                {currentTrack.title || 'Unknown Track'}
             </span>
             <span className="text-[9px] themed-text-muted truncate"> {/* Reduced font size */}
                {audioQueue.length > 0 ? `Queue: ${audioQueue.length} items` : 'Single Track'}
             </span>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-0.5"> {/* Reduced space-x */}
             <Button onClick={playPreviousInQueue} size="icon" variant="ghost" className="h-7 w-7 themed-text-primary hover:themed-bg-secondary"> {/* Reduced size */}
                 <SkipBack size={12} /> {/* Reduced icon size */}
             </Button>
             
             <Button onClick={togglePlay} size="icon" variant="ghost" className={cn("h-7 w-7 themed-text-accent hover:themed-bg-secondary", isPlaying && "animate-pulse")}> {/* Reduced size */}
                 {isPlaying ? <Pause size={14} /> : <Play size={14} />} {/* Reduced icon size */}
             </Button>
             
             <Button onClick={stopAudio} size="icon" variant="ghost" className="h-7 w-7 themed-text-primary hover:themed-bg-secondary"> {/* Reduced size */}
                 <StopCircle size={12} /> {/* Reduced icon size */}
             </Button>

             <Button onClick={playNextInQueue} size="icon" variant="ghost" className="h-7 w-7 themed-text-primary hover:themed-bg-secondary"> {/* Reduced size */}
                 <SkipForward size={12} /> {/* Reduced icon size */}
             </Button>
          </div>

          {/* Volume */}
          <div className="flex items-center space-x-1 w-20 hidden sm:flex"> {/* Reduced space-x, width */}
             <Button onClick={toggleMute} size="icon" variant="ghost" className="h-5 w-5 themed-text-primary"> {/* Reduced size */}
                 {isMuted || volume === 0 ? <VolumeX size={12} /> : <Volume2 size={12} />} {/* Reduced icon size */}
             </Button>
             <Slider
                value={[isMuted ? 0 : volume]}
                max={1}
                step={0.01}
                onValueChange={handleVolumeChange}
                className="w-14" // Reduced width
             />
          </div>
      </div>
    </div>
  );
};

export default AudioPlayer;
