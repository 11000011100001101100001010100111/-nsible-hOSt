
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDesk } from '@/contexts/DeskContext';
import { useTheme } from '@/contexts/ThemeContext';
import { cn } from '@/lib/utils';
import { Terminal, Activity } from 'lucide-react';

import Codex from '@/components/Codex';
import TerminalOutput from '@/components/TerminalOutput';
import MessageCenter from '@/components/MessageCenter';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import DeskIcon from '@/components/ui/DeskIcon';
import CodexIcon from '@/components/ui/CodexIcon';
import CycleClock from '@/components/CycleClock';

const IconButton = ({ icon: Icon, label, active, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.button
      onClick={onClick}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className={cn(
        "relative flex items-center px-2 py-1.5 rounded-sm text-sm transition-colors touch-manipulation", 
        active ? 'themed-bg-accent themed-text-primary' : 'hover:themed-bg-accent/50',
        "active:scale-95" 
      )}
    >
      <Icon size={16} />
      <AnimatePresence>
        {(isHovered || active) && (
          <motion.span
            initial={{ opacity: 0, x: -10, width: 0 }}
            animate={{ opacity: 1, x: 0, width: 'auto' }}
            exit={{ opacity: 0, x: -10, width: 0 }}
            className="ml-1 text-xs whitespace-nowrap overflow-hidden"
            transition={{ duration: 0.2 }}
          >
            {label}
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
};

const AnsibleDesk = () => {
  const { user } = useAuth();
  const { isDeskOpen, closeDesk, isDeskLoading, editingFile, setEditingFile, activePanel, setActivePanel, commandHistory, isRadioVisible } = useDesk();
  const { theme } = useTheme();

  useEffect(() => {
    if (activePanel === 'forum') {
        setActivePanel('timeline');
    }
  }, [activePanel, setActivePanel]);

  useEffect(() => {
    if (!isDeskOpen) {
      setEditingFile(null);
    }
  }, [isDeskOpen, setEditingFile]);

  if (!isDeskOpen) {
    return null;
  }

  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
  };

  const deskVariants = {
    hidden: { y: '-100%', opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', damping: 25, stiffness: 150 } },
    exit: { y: '-100%', opacity: 0, transition: { duration: 0.3 } },
  };

  return (
    <motion.div
      className="fixed inset-0 z-40 bg-black/50 backdrop-blur-[1px]"
      variants={backdropVariants}
      initial="hidden"
      animate="visible"
      exit="hidden"
      onClick={closeDesk}
    >
      <motion.div
        className={cn(
          "fixed top-0 left-0 right-0 flex flex-col terminal-text themed-bg-primary shadow-2xl shadow-black overflow-hidden",
          "h-[100dvh] md:h-[75vh]",
          "rounded-b-none md:rounded-b-lg",
          "border-b-0" 
        )}
        style={{
          '--desk-transparency': `${theme.transparency || 0}%`,
          backgroundColor: `rgba(var(--color-primary-bg-val), calc(1 - var(--desk-transparency) / 100))`,
        }}
        variants={deskVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header - Optimized layout to avoid prompt overlap */}
        <header className="flex items-center p-2 border-b-2 themed-border-secondary flex-shrink-0 bg-black/10">
           {/* Title Section */}
           <div 
             className="flex items-center space-x-1 cursor-pointer p-1 rounded-full hover:themed-bg-accent active:bg-white/10 transition-colors mr-2"
             onClick={closeDesk}
             title="Close Desk"
           >
            <DeskIcon className="w-5 h-5 themed-text-accent" />
            <div className="flex flex-col ml-1">
              <h1 className="text-sm font-bold tracking-tight hidden xs:block leading-none">@nsible</h1>
              <span className="text-[8px] font-mono text-muted-foreground hidden xs:block leading-none opacity-70">ALPHA 0.1.0</span>
            </div>
          </div>

          <CycleClock />
          
          {/* Navigation Tabs - Moved LEFT with Expanded Labels */}
          <div className="flex space-x-1 overflow-x-auto no-scrollbar mr-auto ml-2">
             <IconButton
              icon={Terminal}
              label="Terminal"
              active={activePanel === 'terminal'}
              onClick={() => setActivePanel('terminal')}
            />
            <IconButton
              icon={CodexIcon}
              label="Codex"
              active={activePanel === 'codex'}
              onClick={() => setActivePanel('codex')}
            />
            {/* Unified Activity Tab - Renamed to @://nsible */}
            <IconButton
              icon={Activity}
              label="@://nsible"
              active={activePanel === 'timeline' || activePanel === 'forum'}
              onClick={() => setActivePanel('timeline')}
            />
          </div>

          {/* Status Indicators - Pushed right but kept clear of corner */}
          {isDeskLoading && <div className="mr-12 h-3 w-3 border-2 border-dashed themed-border-accent rounded-full animate-spin"></div>}
        </header>

        {/* Main Content Area */}
        <main 
            className={cn(
                "flex-grow p-2 sm:p-3 overflow-hidden relative flex flex-col",
                // Add padding bottom to avoid overlap with RadioBar if it's visible and we are full screen
                isRadioVisible ? "pb-20 md:pb-3" : "pb-safe-area"
            )}
        >
          <div className="flex-grow min-h-0 overflow-hidden relative rounded-md border themed-border-secondary/30 bg-black/20">
             {activePanel === 'terminal' && <TerminalOutput events={commandHistory} />}
             {activePanel === 'codex' && <Codex />}
             {(activePanel === 'timeline' || activePanel === 'forum') && <MessageCenter user={user} />}
          </div>
        </main>
      </motion.div>
    </motion.div>
  );
};

export default AnsibleDesk;
