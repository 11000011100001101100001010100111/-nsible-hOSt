
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import MatrixRain from '@/components/MatrixRain';
import DeskIcon from '@/components/ui/DeskIcon';

const IntroScreen = () => {
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowContent(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleMantraClick = () => {
    window.open('https://hostinger.com/horizons?REFERRALCODE=FCQ010001RH8', '_blank');
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-black relative overflow-hidden">
      <MatrixRain />
      {showContent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 2 }}
          className="relative z-10 text-center px-3 py-2" // Reduced padding
        >
          <motion.div
            initial={{ y: -40, opacity: 0 }} // Reduced y offset
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="flex justify-center items-center mb-6" // Reduced margin-bottom
          >
            <DeskIcon className="w-20 h-20 themed-text-primary" /> {/* Reduced icon size */}
          </motion.div>
          <motion.h1
            initial={{ y: 40, opacity: 0 }} // Reduced y offset
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="text-3xl md:text-5xl font-bold terminal-text themed-text-primary mb-3" // Reduced font size, margin-bottom
          >
            @NSIBLE
          </motion.h1>
          <motion.p
            initial={{ y: 40, opacity: 0 }} // Reduced y offset
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 1.5 }}
            className="text-base md:text-lg terminal-text themed-text-secondary mb-6" // Reduced font size, margin-bottom
          >
            L'avenir de demain, aujourd'hui!
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 2 }}
            className="text-xs terminal-text text-red-500 cursor-pointer hover:text-red-400 hover:animate-pulse" // Reduced font size
            onClick={handleMantraClick}
          >
            ILLUMINATUS AEQUATUS @ EVOCATUS SALARARIUS
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default IntroScreen;
