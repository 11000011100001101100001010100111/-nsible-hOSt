
import React, { useMemo } from 'react';
import { useDesk } from '@/contexts/DeskContext';

const b64DecodeUnicode = (str) => {
  try {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (e) {
    return str;
  }
};

const LsOutput = ({ items: initialItems = [], path = '~', pathKeys = null }) => {
  const { fileSystem, getCurrentDirectory } = useDesk();

  // "Live" view of the items if pathKeys are provided
  // This hook subscribes to the fileSystem context, ensuring the list updates in real-time
  const liveItems = useMemo(() => {
    if (!pathKeys || !fileSystem) return null;
    
    // Resolve the node dynamically based on the path keys
    const node = getCurrentDirectory(fileSystem, pathKeys);
    if (!node) return null; // Directory might have been deleted or path invalid

    return Object.entries(node).map(([key, val]) => ({
      name: b64DecodeUnicode(key),
      type: val.type
    })).sort((a, b) => {
        if (a.type === b.type) return a.name.localeCompare(b.name);
        return a.type === 'folder' ? -1 : 1;
    });
  }, [fileSystem, pathKeys, getCurrentDirectory]);

  // Use live items if available and valid, otherwise fall back to initial snapshot
  const displayItems = liveItems || initialItems;
  const isLive = !!liveItems;

  if (!displayItems || !Array.isArray(displayItems)) {
    return (
      <div className="my-1.5 px-2 py-1 bg-zinc-900/30 rounded border border-zinc-800 text-xs">
         <p className="text-zinc-400 mb-1 text-[10px] uppercase tracking-wider border-b border-zinc-700 pb-0.5">Index of {path}</p>
         <p className="text-red-400 italic">Error retrieving directory listing.</p>
      </div>
    );
  }

  return (
    <div className="my-1.5 px-2 py-1 bg-zinc-900/30 rounded border border-zinc-800 text-xs transition-colors duration-500" style={{ borderColor: isLive ? 'rgba(50, 205, 50, 0.2)' : '' }}>
      <div className="flex justify-between items-end border-b border-zinc-700 pb-0.5 mb-1">
          <p className="text-zinc-400 text-[10px] uppercase tracking-wider">Index of {path}</p>
          {isLive && <span className="text-[9px] text-green-500/50 font-mono animate-pulse" title="Real-time Sync Active">LIVE</span>}
      </div>
      
      {displayItems.length === 0 ? (
        <p className="text-zinc-600 italic">Directory is empty.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-3 gap-y-1">
          {displayItems.map((item, index) => {
            if (!item) return null;
            const isFolder = item.type === 'folder';
            return (
              <div key={`${item.name}-${index}`} className="flex items-center space-x-1.5 group">
                <span className={isFolder ? 'text-yellow-500' : 'text-red-500'}>
                  {isFolder ? '📂' : '📄'}
                </span>
                <span
                  className={isFolder 
                    ? 'text-yellow-400 font-bold group-hover:text-yellow-300 transition-colors' 
                    : 'text-red-400 group-hover:text-red-300 transition-colors'
                  }
                >
                  {item.name}
                  {isFolder && '/'}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default LsOutput;
