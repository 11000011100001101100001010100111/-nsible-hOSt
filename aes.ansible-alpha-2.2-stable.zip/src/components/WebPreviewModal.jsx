
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { useDesk } from '@/contexts/DeskContext';
import { X, ExternalLink, Code, Phone, Globe } from 'lucide-react';

const WebPreviewModal = ({ data, onClose, onViewSource }) => {
  const { theme } = useTheme();
  const { openWebFrame } = useDesk();

  if (!data) return null;
  
  const transparencyClass = `bg-black/${theme.transparency}`;

  const protocol = data.url.split(':')[0].toLowerCase();
  let buttonText = 'Launch';
  let ButtonIcon = ExternalLink;

  if (['http', 'https'].includes(protocol)) {
    buttonText = 'Open Frame';
    ButtonIcon = Globe;
  } else if (protocol === 'tel') {
    buttonText = 'Connect';
    ButtonIcon = Phone;
  } else if (protocol === 'sms') {
    buttonText = 'Transmit';
    ButtonIcon = ExternalLink;
  }


  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className={`fixed inset-0 ${transparencyClass} backdrop-blur-sm flex items-center justify-center z-50 p-3`} // Reduced padding
        onClick={onClose}
      >
        <motion.div
          initial={{ y: -20, opacity: 0 }} // Reduced y offset
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 20, opacity: 0 }} // Reduced y offset
          transition={{ duration: 0.3, ease: 'easeInOut' }}
          className="relative bg-black/80 border themed-border-secondary rounded-md shadow-xl w-full max-w-md terminal-text flex flex-col" // Reduced max-width, rounded, shadow
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-start p-3 border-b themed-border-secondary"> {/* Reduced padding */}
            {data.image && (
              <div className="flex-shrink-0 w-14 h-14 mr-3 bg-black/30 rounded-sm flex items-center justify-center overflow-hidden"> {/* Reduced size, margin, rounded */}
                <img src={data.image} alt={data.title} className="w-full h-full object-cover" />
              </div>
            )}
            <div className="flex-grow min-w-0">
              <h2 className="text-base font-bold themed-text-primary truncate">{data.title}</h2> {/* Reduced font size */}
              <p className="text-xs themed-text-secondary truncate">{data.url}</p> {/* Reduced font size */}
              <div className="mt-1.5 text-xs themed-text-accent leading-snug max-h-20 overflow-y-auto pr-1.5"> {/* Reduced margin-top, font size, max-height, padding-right */}
                 <p className="whitespace-pre-wrap">{data.description}</p>
              </div>
            </div>
            <Button onClick={onClose} variant="ghost" size="icon" className="ml-3 -mt-1.5 -mr-1.5 flex-shrink-0 text-gray-400 hover:themed-text-accent h-7 w-7"> {/* Reduced margin, size */}
              <X className="w-4 h-4" /> {/* Reduced icon size */}
            </Button>
          </div>

          <div className="flex justify-end space-x-1.5 p-2 bg-black/20"> {/* Reduced space-x, padding */}
            <Button onClick={onViewSource} variant="outline" size="sm" className="themed-border-secondary themed-text-secondary hover:themed-bg-secondary hover:text-black h-8 px-2 text-xs"> {/* Reduced height, padding, font size */}
              <Code className="w-3.5 h-3.5 mr-1.5" /> {/* Reduced icon size, margin */}
              Source
            </Button>
            <Button 
              onClick={() => {
                if (['http', 'https'].includes(protocol)) {
                  openWebFrame(data.url, data.title);
                  onClose();
                } else if (['tel', 'sms', 'mailto'].includes(protocol)) {
                  window.location.href = data.url;
                } else {
                  window.open(data.url, '_blank');
                }
              }} 
              size="sm"
              className="themed-bg-primary hover:themed-bg-accent text-black h-8 px-2 text-xs" // Reduced height, padding, font size
            >
              <ButtonIcon className="w-3.5 h-3.5 mr-1.5" /> {/* Reduced icon size, margin */}
              {buttonText}
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default WebPreviewModal;
