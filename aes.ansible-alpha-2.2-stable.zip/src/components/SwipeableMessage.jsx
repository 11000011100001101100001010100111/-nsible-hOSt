
import React, { useRef, useState } from 'react';
import { motion, useMotionValue, useTransform, AnimatePresence } from 'framer-motion';
import { Reply, Trash2, Archive, Check, X, MoreVertical, Eye, EyeOff, ShieldAlert, Star, CheckCircle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const ActionButton = ({ icon: Icon, color, onClick, label, position }) => (
  <button
    onClick={(e) => { e.stopPropagation(); onClick(); }}
    className={cn(
      "absolute top-0 bottom-0 w-16 flex flex-col items-center justify-center text-white transition-colors",
      color,
      position === 'right' ? 'right-0' : 'left-0'
    )}
  >
    <Icon className="w-5 h-5 mb-1" />
    <span className="text-[9px] font-bold">{label}</span>
  </button>
);

const SwipeableMessage = ({ 
  msg, 
  onReply, 
  onDelete, 
  onArchive, 
  onToggleRead, 
  onPermit, 
  onBan, 
  isExpanded, 
  onToggleExpand, 
  formatTime,
  themeTimeFormat,
  onContextMenu
}) => {
  const x = useMotionValue(0);
  const dragControls = useMotionValue(0);
  const [isDragging, setIsDragging] = useState(false);
  const touchStartTime = useRef(0);
  const longPressTimer = useRef(null);

  // Background Opacity Transforms
  const rightOpacity = useTransform(x, [-100, -50], [1, 0]);
  const leftOpacity = useTransform(x, [50, 100], [0, 1]);
  
  // Constrain swipe
  const handleDragEnd = (event, info) => {
    setIsDragging(false);
    const offset = info.offset.x;
    const velocity = info.velocity.x;

    if (offset < -100) {
      // Swiped Left far enough
      // onDelete(); 
      // Reset for now as we want buttons to be clickable, not auto-trigger usually, but here we can snap back
    } 
  };

  const handleTouchStart = (e) => {
    touchStartTime.current = Date.now();
    longPressTimer.current = setTimeout(() => {
      if (!isDragging) {
        onContextMenu(e, msg);
      }
    }, 600);
  };

  const handleTouchEnd = () => {
    if (longPressTimer.current) clearTimeout(longPressTimer.current);
  };

  const handleMove = () => {
    if (longPressTimer.current) clearTimeout(longPressTimer.current);
    setIsDragging(true);
  };
  
  const isRequest = msg.is_request;
  const isCollected = msg.is_collected;
  const isRead = msg.is_read;

  return (
    <div className="relative overflow-hidden mb-2 rounded-md group touch-pan-y">
      {/* Background Actions Layer */}
      <div className="absolute inset-0 flex justify-between rounded-md overflow-hidden bg-black/40">
        {/* Left Actions (Reveal on swipe right) */}
        <div className="flex w-1/2 h-full relative">
           <motion.div style={{ opacity: leftOpacity }} className="flex h-full">
              <ActionButton 
                  icon={Reply} 
                  color="bg-blue-600" 
                  label="REPLY" 
                  position="left" 
                  onClick={() => onReply(msg)} 
              />
               <div className="w-16 ml-16 flex flex-col items-center justify-center bg-amber-600 text-white h-full" onClick={() => onArchive(msg)}>
                   <Archive className="w-5 h-5 mb-1" />
                   <span className="text-[9px] font-bold">SAVE</span>
               </div>
           </motion.div>
        </div>

        {/* Right Actions (Reveal on swipe left) */}
        <div className="flex w-1/2 h-full justify-end relative">
            <motion.div style={{ opacity: rightOpacity }} className="flex h-full">
               <div className="w-16 mr-16 flex flex-col items-center justify-center bg-gray-600 text-white h-full" onClick={() => onToggleRead(msg)}>
                    {isRead ? <Eye className="w-5 h-5 mb-1" /> : <EyeOff className="w-5 h-5 mb-1" />}
                    <span className="text-[9px] font-bold">{isRead ? "UNREAD" : "READ"}</span>
               </div>
               <ActionButton 
                   icon={Trash2} 
                   color="bg-red-600" 
                   label="DELETE" 
                   position="right" 
                   onClick={() => onDelete(msg)} 
               />
            </motion.div>
        </div>
      </div>

      {/* Foreground Message Content */}
      <motion.div
        drag="x"
        dragConstraints={{ left: -140, right: 140 }}
        dragElastic={0.1}
        onDragStart={() => handleMove()}
        onDragEnd={handleDragEnd}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onTouchMove={handleMove}
        style={{ x, touchAction: 'pan-y' }}
        className={cn(
          "relative z-10 p-3 rounded-md border-l-4 transition-colors shadow-sm",
          isRequest ? "bg-red-950/80 border-red-500" : (isCollected ? "bg-amber-900/40 border-amber-500" : "bg-zinc-900/90 border-zinc-700"),
          !isRead && !isRequest && !isCollected ? "border-l-fuchsia-500 bg-zinc-800" : ""
        )}
        onClick={() => {
            if(!isDragging) onToggleExpand(msg.id);
        }}
      >
        <div className="flex justify-between items-start mb-1 pointer-events-none">
             <div className="flex items-center gap-2">
                 {isRequest && <ShieldAlert className="w-4 h-4 text-red-500 animate-pulse" />}
                 {isCollected && <Star className="w-4 h-4 text-amber-400" />}
                 <span className={cn("font-bold text-xs", isRequest ? "text-red-400" : "text-fuchsia-400")}>
                    {msg.sender_username}
                 </span>
             </div>
             <span className="text-[10px] text-zinc-500 tabular-nums">
                 {formatTime(msg.created_at, themeTimeFormat)}
             </span>
        </div>

        <div className="text-xs text-zinc-300 leading-relaxed break-words pointer-events-none">
             {msg.content}
        </div>

        {/* Expanded Content / Actions */}
        <AnimatePresence>
            {isExpanded && (
                <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden mt-3 pt-2 border-t border-white/10"
                >
                    {isRequest ? (
                         <div className="flex items-center gap-2 pt-1">
                             <Button size="sm" className="h-7 text-[10px] bg-emerald-700 hover:bg-emerald-600 text-white gap-1 flex-1" onClick={(e) => { e.stopPropagation(); onPermit(msg); }}>
                                  <CheckCircle className="w-3 h-3" /> PERMIT
                             </Button>
                             <Button size="sm" variant="destructive" className="h-7 text-[10px] gap-1 flex-1" onClick={(e) => { e.stopPropagation(); onBan(msg); }}>
                                  <XCircle className="w-3 h-3" /> BAN
                             </Button>
                         </div>
                    ) : (
                         <div className="flex items-center justify-end gap-2 text-[10px] text-zinc-500 italic">
                             <span>Swipe for actions</span>
                             <MoreVertical className="w-3 h-3" />
                         </div>
                    )}
                </motion.div>
            )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default SwipeableMessage;
