
import React, { useState, useRef, useCallback, forwardRef, useImperativeHandle, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDesk } from '@/contexts/DeskContext';
import { useTheme } from '@/contexts/ThemeContext';
import { useTemporal } from '@/contexts/TemporalContext';
import WebPreviewModal from '@/components/WebPreviewModal';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/customSupabaseClient';

const b64DecodeUnicode = (str) => {
  try {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (e) {
    return str;
  }
};

const CYCLE_SECONDS = 42 * 60 + 8; // ~2528 seconds
const EPHEMERAL_LIFETIME = CYCLE_SECONDS * 0.1 * 1000; // 1/10th of a cycle in ms

const CommandPrompt = forwardRef((props, ref) => {
  const [input, setInput] = useState('');
  const [commandHistory, setCommandHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [lastCommand, setLastCommand] = useState('');
  const [awaitingScanConfirmation, setAwaitingScanConfirmation] = useState(false);
  const inputRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, setTheme } = useTheme();
  const { user, refreshProfile } = useAuth();
  const { addEvent } = useTemporal();
  
  const { 
      isDeskOpen, openDesk, closeDesk, addCommandOutput, 
      handleLs, handleCd, handleMkdir, handleTouch, handleRm, handleCp, handleMv, catFile, updateFileSystem,
      activePanel, setActivePanel, backgroundActivity, setEditingFile,
      userFrequency, fetchUserByFrequency, fetchUserByUsername, publishBroadcast, editingFile,
      startModulation, clearCommandHistory, currentPath, getBroadcastLink,
      // Radio / Audio Controls
      isPlaying, togglePlay, playNextInQueue, scanMedia, playTrack, currentTrack, audioQueue,
      isBroadcasting, toggleBroadcast, stopAudio, setRadioVisible
  } = useDesk();

  const [previewData, setPreviewData] = useState(null);
  const pwdRef = useRef(false);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [snapRecipient, setSnapRecipient] = useState(null);

  useImperativeHandle(ref, () => ({
    focusInput: () => inputRef.current?.focus(),
    get inputRef() { return inputRef.current; }
  }));

  // PWD Output Effect
  useEffect(() => {
    if (pwdRef.current) {
        const pathStr = currentPath.length === 0 ? '~' : '~/' + currentPath.map(p => b64DecodeUnicode(p)).join('/');
        addCommandOutput({ type: 'success', title: 'PWD', message: pathStr });
        pwdRef.current = false;
    }
  }, [currentPath, addCommandOutput]);

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = Math.min(historyIndex + 1, commandHistory.length - 1);
        setHistoryIndex(newIndex);
        setInput(commandHistory[newIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > -1) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setInput(newIndex >= 0 ? commandHistory[newIndex] : '');
      }
    } else if (e.key === 'Escape' && isCameraActive) {
        stopCamera();
    }
  };
  
  // Fix Android prompt cursor issue
  const handleChange = (e) => {
      const newValue = e.target.value;
      setInput(newValue);
      
      // Android specific fix: If input length is 1 (first char entered), force cursor to end
      if (newValue.length === 1 && inputRef.current) {
          requestAnimationFrame(() => {
              if (inputRef.current) {
                  inputRef.current.selectionStart = 1;
                  inputRef.current.selectionEnd = 1;
              }
          });
      }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach(track => track.stop());
        videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setSnapRecipient(null);
    addCommandOutput({ type: 'info', title: 'Camera', message: 'Visual sensor disengaged.' });
  };

  const capturePhoto = async () => {
      if (!videoRef.current || !canvasRef.current) return;
      
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Apply "cyber" filter effect
      const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      for (let i = 0; i < data.length; i += 4) {
          data[i] = data[i] * 1.1;     // Boost red slightly
          data[i + 1] = data[i + 1]; // Green
          data[i + 2] = data[i + 2] * 1.2; // Boost blue for cold look
      }
      context.putImageData(imageData, 0, 0);

      // Add timestamp watermark
      context.font = '12px monospace';
      context.fillStyle = 'rgba(255, 255, 255, 0.7)';
      context.fillText(new Date().toISOString(), 10, canvas.height - 10);
      context.fillText('@nsible_OPTICS', 10, canvas.height - 25);

      canvas.toBlob(async (blob) => {
          if (!blob) {
             addCommandOutput({ type: 'error', title: 'Camera', message: 'Capture failed.' });
             stopCamera();
             return;
          }

          const filename = `snap_${Date.now()}.png`;
          const filepath = `${user.id}/${filename}`;

          // Upload to Storage
          const { data: uploadData, error: uploadError } = await supabase.storage
              .from('user_files')
              .upload(filepath, blob, { contentType: 'image/png' });

          if (uploadError) {
              addCommandOutput({ type: 'error', title: 'Storage', message: uploadError.message });
              stopCamera();
              return;
          }

          // Save to Filesystem
          const b64Name = btoa(filename);
          await updateFileSystem(`Captured ${filename}`, {
              key: b64Name,
              value: { type: 'file', content: '[IMAGE_DATA]', storagePath: filepath, mimeType: 'image/png' },
              append: false
          });

          addCommandOutput({ type: 'success', title: 'Camera', message: `Image captured and saved as ${filename}` });

          // Send if recipient exists
          if (snapRecipient) {
              const { data: signedUrlData } = await supabase.storage.from('user_files').createSignedUrl(filepath, EPHEMERAL_LIFETIME / 1000); // URL valid for life of message
              
              if (signedUrlData) {
                  const content = `[EPHEMERAL::SNAP] Incoming visual transmission. Auto-deletes in ${EPHEMERAL_LIFETIME / 1000}s.\n[VIEW](${signedUrlData.signedUrl})`;
                  
                  // Send Message
                  const { error: msgError } = await supabase.from('messages').insert({
                      sender_id: user.id,
                      sender_username: user.username,
                      recipient_id: snapRecipient.id,
                      content: content,
                      is_broadcast: false,
                      is_read: false
                  });

                  if (!msgError) {
                       addCommandOutput({ type: 'success', title: 'Transmission', message: `Snap sent to ${snapRecipient.username}.` });
                       
                       // Schedule Deletion (Best effort client-side for this demo, ideal is edge function)
                       setTimeout(async () => {
                            // Delete from storage to invalidate link effectively
                            await supabase.storage.from('user_files').remove([filepath]);
                            // Note: Message record remains but link is dead.
                       }, EPHEMERAL_LIFETIME);
                  } else {
                       addCommandOutput({ type: 'error', title: 'Transmission', message: 'Failed to send snap.' });
                  }
              }
          }

          stopCamera();
      }, 'image/png');
  };

  const handleSnap = async (args) => {
      // Check for recipient
      let recipient = null;
      if (args.length > 1 && args[0] === 'to') {
           const username = args[1];
           recipient = await fetchUserByUsername(username);
           if (!recipient) {
               addCommandOutput({ type: 'error', title: 'Snap', message: `User ${username} not found.` });
               return;
           }
      }

      setSnapRecipient(recipient);
      setIsCameraActive(true);
      addCommandOutput({ type: 'info', title: 'Camera', message: 'Initializing optics...' });

      try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          if (videoRef.current) {
              videoRef.current.srcObject = stream;
              videoRef.current.play();
          }
      } catch (err) {
          addCommandOutput({ type: 'error', title: 'Camera', message: 'Access denied or device not found.' });
          setIsCameraActive(false);
          setSnapRecipient(null);
      }
  };

  const showHelp = () => {
    addCommandOutput({ type: 'info', title: "File Management", message: 
`  ls [dir]        List directory contents
  cd <dir>        Change directory
  mkdir <name>    Create directory
  touch <name>    Create empty file
  cp <src> <dst>  Copy file
  mv <src> <dst>  Move/Rename file
  rm <name>       Remove file
  cat <file>      Display file content
  snap [to @user] Capture photo (optional: send ephemeral)
  codex [file]    Open Codex editor` 
    });
    addCommandOutput({ type: 'info', title: "Temporal", message: 
`  date            Show current date
  time            Show current system time
  log <msg>       Log note to personal timeline
  timeline        Open unified activity log` 
    });
    addCommandOutput({ type: 'info', title: "Radio System", message: 
`  radio play      Start/Open audio player
  radio off       Stop and close radio
  radio stop      Pause playback
  radio next      Skip current track
  radio scan      Scan local frequency (play random)
  radio tx        Toggle broadcast transmission` 
    });
    addCommandOutput({ type: 'info', title: "Broadcast", message: 
`  whois           View your frequency info
  whois edit      Edit your broadcast page
  whois static    Preview current broadcast HTML
  whois <freq>    Tune to a frequency
  whois <user>    Lookup user frequency
  publish         Save active broadcast edit` 
    });
    addCommandOutput({ type: 'info', title: "System", message: 
`  desk [close]    Toggle desk
  terminal        Switch to terminal
  forum           Switch to activity/comms
  login           Open login interface
  clear           Clear terminal output
  exit            Logout` 
    });
  };

  const handleWhois = async (arg) => {
      if (!arg) {
          addCommandOutput({ type: 'info', title: 'Identity', message: `User: ${user.email}\nFrequency: ${userFrequency || 'Scanning...'}` });
          return;
      }
      
      if (arg === 'edit') {
          if (!isDeskOpen) openDesk();
          
          // Ensure we have the latest profile data (html)
          addCommandOutput({ type: 'info', title: 'System', message: 'Fetching latest broadcast data...' });
          await refreshProfile();
          
          setActivePanel('codex');
          const currentContent = user.profile?.public_page_html || '<h1>Welcome to my frequency.</h1>\n<p>Signal established.</p>';
          setEditingFile({
              name: 'broadcast.html',
              content: currentContent,
              type: 'system_html',
              path: []
          });
          addCommandOutput({ type: 'success', title: 'Editor', message: 'Broadcast channel opened for editing.' });
          return;
      }
      
      if (arg === 'static' || arg === 'preview') {
          const currentContent = user.profile?.public_page_html || '<h1>No Broadcast Content</h1><p>Use "whois edit" to set your signal.</p>';
          setPreviewData({
              description: currentContent, // Mapped to description for modal preview
              url: `local://${userFrequency || 'UNKNOWN'}/index.html`,
              title: 'Broadcast Preview'
          });
          addCommandOutput({ type: 'success', title: 'Preview', message: 'Generating local rendering...' });
          return;
      }

      addCommandOutput({ type: 'info', title: 'Scanner', message: `Scanning for signal: ${arg}...` });
      
      let targetUser = null;
      if (arg.startsWith('@')) {
          targetUser = await fetchUserByUsername(arg);
      } else if (arg.match(/^[A-Z]{2,3}-\d+\.\d+Hz$/)) {
          targetUser = await fetchUserByFrequency(arg);
      } else {
          targetUser = await fetchUserByUsername(arg);
      }

      if (targetUser) {
          const freq = targetUser.profile?.profile_info?.frequency;
          addCommandOutput({ type: 'success', title: 'Signal Found', message: `User: ${targetUser.username}\nFrequency: ${freq}` });
          if (freq) {
             window.dispatchEvent(new CustomEvent('openBroadcastModal', { 
                 detail: { 
                     user: targetUser.username, 
                     freq: freq, 
                     title: targetUser.username + "'s Signal" 
                 } 
             }));
          }
      } else {
          addCommandOutput({ type: 'error', title: 'Scanner', message: 'No signal detected on that band.' });
      }
  };

  const handlePublish = async () => {
      if (editingFile?.name === 'broadcast.html') {
          try {
             await publishBroadcast(editingFile.content);
          } catch(e) {
             // Error handled in context
          }
      } else {
          addCommandOutput({ type: 'error', title: 'Publish', message: 'No active broadcast file open in Codex.' });
      }
  };

  const handleModulation = async (myUser, targetUser) => {
    if (myUser.toLowerCase() !== user.username.toLowerCase()) {
         addCommandOutput({ type: 'error', title: 'Security', message: `Identity mismatch. You are logged in as ${user.username}.` });
         return;
    }
    
    if (!userFrequency?.startsWith('XMF')) {
        addCommandOutput({ type: 'error', title: 'Access Denied', message: 'Insufficient frequency privileges. XMF band required.' });
        return;
    }

    try {
        await startModulation(targetUser);
    } catch(e) {
        addCommandOutput({ type: 'error', title: 'Modulation Failed', message: e.message });
    }
  };

  const handleCommand = useCallback(async (command) => {
    if (!command) return;

    // Handle Confirmation State for Radio Scan
    if (awaitingScanConfirmation) {
        setAwaitingScanConfirmation(false);
        const response = command.toLowerCase().trim();
        addCommandOutput({ type: 'command', message: command }); // Echo user input

        if (['y', 'yes'].includes(response)) {
             await handleCommand('radio scan'); // Execute scan
        } else {
             addCommandOutput({ type: 'info', title: 'RADIO', message: 'Empty Deck.' });
        }
        
        // Update history and cleanup
        setCommandHistory(prev => [command, ...prev.filter(c => c !== command)].slice(0, 50));
        setHistoryIndex(-1);
        setLastCommand(command);
        setInput('');
        return;
    }

    setCommandHistory(prev => [command, ...prev.filter(c => c !== command)].slice(0, 50));
    setHistoryIndex(-1);
    addCommandOutput({ type: 'command', message: command });

    const parts = command.match(/(?:[^\s"]+|"[^"]*")+/g) || [];
    let cmd = parts[0]?.toLowerCase();
    let args = parts.slice(1).map(arg => arg.replace(/"/g, ''));

    const publicCommands = ['help', 'login', 'exit', 'theme', 'clear'];
    if (['@://shell', 'shell'].includes(command.toLowerCase())) {
         const newState = !theme.kiosk;
         setTheme({ kiosk: newState });
         if (newState) { if (isDeskOpen) closeDesk(); document.documentElement.requestFullscreen().catch(console.error); }
         else { if (document.fullscreenElement) document.exitFullscreen(); }
         addCommandOutput({ type: 'success', title: 'System', message: `Kiosk Mode: ${newState ? 'ON' : 'OFF'}` });
         setInput(''); return;
    }

    if (!user && !publicCommands.includes(cmd)) {
        addCommandOutput({ type: 'error', title: "Access Denied", message: "Login required." });
        setInput(''); return;
    }
    
    if (user && parts.length === 3 && parts[1].toLowerCase() === 'x') {
        await handleModulation(parts[0], parts[2]);
        setLastCommand(command);
        setInput('');
        return;
    }

    if (user && ['ls', 'cd', 'mkdir', 'touch', 'cp', 'mv', 'rm', 'cat', 'help', 'whois'].includes(cmd)) {
        if (!isDeskOpen) openDesk();
        if (activePanel !== 'terminal') setActivePanel('terminal');
    }

    setLastCommand(command);
    setInput('');

    try {
        switch (cmd) {
            case 'help': showHelp(); break;
            case 'login': 
                if (user) {
                    addCommandOutput({ type: 'info', title: 'System', message: `Already logged in as ${user.email}.` });
                } else {
                    window.dispatchEvent(new Event('toggleLoginModal'));
                }
                break;
            case 'clear': 
                clearCommandHistory(); 
                break;
            case 'date': 
                addCommandOutput({ type: 'success', title: 'DATE', message: new Date().toLocaleDateString() }); 
                break;
            case 'time': 
                addCommandOutput({ type: 'success', title: 'TIME', message: new Date().toLocaleTimeString() }); 
                break;
            case 'log':
                if (args.length === 0) {
                     addCommandOutput({ type: 'error', title: 'LOG', message: 'Usage: log <message>' });
                } else {
                     const msg = args.join(' ');
                     await addEvent('note', 'User Note', msg);
                     addCommandOutput({ type: 'success', title: 'LOG', message: 'Note recorded to timeline.' });
                }
                break;
            case 'ls': handleLs(args[0]); break;
            case 'cd': 
                await handleCd(args[0]); 
                pwdRef.current = true;
                break;
            case 'mkdir': handleMkdir(args[0]); break;
            case 'touch': handleTouch(args[0]); break;
            case 'rm': handleRm(args[0]); break;
            case 'cp': handleCp(args[0], args[1]); break;
            case 'mv': handleMv(args[0], args[1]); break;
            case 'cat': catFile(args[0]); break;
            case 'snap': await handleSnap(args); break;
            case 'whois': await handleWhois(args[0]); break;
            case 'publish': await handlePublish(); break;
            case 'codex': 
                if (!user) break; 
                setActivePanel('codex');
                if (!isDeskOpen) openDesk();
                if (args.length > 0) {
                     setEditingFile({ name: args[0], content: '', isNew: true });
                } else {
                     setEditingFile(null);
                }
                break;
            case 'desk': 
                if (!user) break;
                if (args[0] === 'close') closeDesk();
                else openDesk(); 
                break;
            case 'terminal': 
                if (!user) break;
                setActivePanel('terminal'); 
                if(!isDeskOpen) openDesk(); 
                break;
            case 'timeline':
            case 'activity':
                if (!user) break;
                setActivePanel('timeline');
                if(!isDeskOpen) openDesk(); 
                break;
            case 'forum': 
                if (!user) break;
                // Redirect forum command to timeline panel
                setActivePanel('timeline'); 
                if(!isDeskOpen) openDesk(); 
                break;
            case 'radio':
                const radioAction = args[0];
                if (!radioAction || radioAction === 'status') {
                     addCommandOutput({ 
                        type: 'info', 
                        title: 'RADIO', 
                        message: `STATUS: ${isPlaying ? 'ACTIVE' : 'IDLE'}\nFREQ: ${userFrequency}\nTRACK: ${currentTrack?.title || 'NONE'}\nTX: ${isBroadcasting ? 'LIVE' : 'OFF'}` 
                    });
                } else if (['play', 'on', 'start'].includes(radioAction)) {
                     // Check if deck is empty
                    if (!currentTrack && (!audioQueue || audioQueue.length === 0)) {
                         addCommandOutput({ type: 'info', title: 'RADIO', message: 'Deck empty. Scan local system? [y/n]' });
                         setAwaitingScanConfirmation(true);
                    } else {
                        // Ensure visibility
                        setRadioVisible(true);
                        if (!isPlaying) togglePlay();
                        addCommandOutput({ type: 'success', title: 'RADIO', message: 'Audio stream ENGAGED.' });
                    }
                } else if (['off', 'close'].includes(radioAction)) {
                    stopAudio();
                    setRadioVisible(false);
                    addCommandOutput({ type: 'info', title: 'RADIO', message: 'Audio system TERMINATED.' });
                } else if (['stop', 'pause'].includes(radioAction)) {
                    if (isPlaying) togglePlay();
                    addCommandOutput({ type: 'info', title: 'RADIO', message: 'Audio stream SUSPENDED.' });
                } else if (['next', 'skip'].includes(radioAction)) {
                    playNextInQueue();
                    addCommandOutput({ type: 'success', title: 'RADIO', message: 'Skipping to next transmission...' });
                } else if (['scan'].includes(radioAction)) {
                     // Ensure visibility for scan
                     setRadioVisible(true);
                     const media = scanMedia();
                     if (media.length > 0) {
                         const randomTrack = media[Math.floor(Math.random() * media.length)];
                         playTrack(randomTrack);
                         addCommandOutput({ type: 'success', title: 'SCANNER', message: `Signal Intercepted: ${randomTrack.title}` });
                     } else {
                         addCommandOutput({ type: 'error', title: 'SCANNER', message: 'No signals detected in local range.' });
                     }
                } else if (['tx', 'broadcast'].includes(radioAction)) {
                    toggleBroadcast();
                    const link = getBroadcastLink();
                    const msg = isBroadcasting 
                        ? 'Terminating signal...' 
                        : `Initiating carrier wave...\nLINK: ${link || 'GENERATING...'}`;
                    addCommandOutput({ type: 'success', title: 'BROADCAST', message: msg });
                } else {
                    addCommandOutput({ type: 'error', title: 'RADIO', message: `Unknown radio command: ${radioAction}` });
                }
                break;
            case 'nav':
                if (location.pathname !== '/nav') {
                    addCommandOutput({ type: 'info', title: 'System', message: 'Initializing Navigation Module...' });
                    navigate('/nav');
                    if (args.length > 0) {
                        setTimeout(() => {
                            const navCmd = 'nav ' + args.join(' ');
                            window.dispatchEvent(new CustomEvent('ansible-command', { detail: { command: navCmd } }));
                        }, 1200); 
                    }
                } else {
                    if (args.length > 0) {
                        const navCmd = 'nav ' + args.join(' ');
                        window.dispatchEvent(new CustomEvent('ansible-command', { detail: { command: navCmd } }));
                    }
                }
                break;
            case 'lab':
            case 'laboratory':
                if (location.pathname !== '/laboratory') {
                    addCommandOutput({ type: 'info', title: 'System', message: 'Connecting to Data Grid...' });
                    navigate('/laboratory');
                    if (args.length > 0) {
                        setTimeout(() => {
                            window.dispatchEvent(new CustomEvent('labCommand', { detail: args }));
                        }, 1200);
                    }
                } else {
                    if (args.length > 0) {
                        window.dispatchEvent(new CustomEvent('labCommand', { detail: args }));
                    }
                }
                break;
            case 'exit': 
                const signOutEvent = new CustomEvent('signOut');
                window.dispatchEvent(signOutEvent);
                break;
            default:
                addCommandOutput({ type: 'error', title: 'Unknown', message: `Command '${cmd}' not recognized. Type 'help'.` });
        }
    } catch (e) {
        addCommandOutput({ type: 'error', title: 'Execution Error', message: e.message });
    }

  }, [user, isDeskOpen, openDesk, activePanel, setActivePanel, handleLs, handleCd, handleMkdir, handleTouch, handleRm, handleCp, handleMv, catFile, addCommandOutput, handleWhois, handlePublish, handleModulation, clearCommandHistory, location.pathname, navigate, currentPath, isPlaying, togglePlay, playNextInQueue, scanMedia, playTrack, currentTrack, userFrequency, isBroadcasting, toggleBroadcast, stopAudio, setRadioVisible, getBroadcastLink, refreshProfile, addEvent, handleSnap, updateFileSystem, awaitingScanConfirmation, audioQueue]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const commandToRun = input.trim();
    if (commandToRun) {
        handleCommand(commandToRun);
    } else { // If command is empty, navigate to timeline
        if (!user) { // Ensure user is logged in
            addCommandOutput({ type: 'error', title: "Access Denied", message: "Login required." });
        } else {
            addCommandOutput({ type: 'info', title: 'System', message: 'Navigating to @://nsible...' });
            if (!isDeskOpen) openDesk();
            setActivePanel('timeline');
        }
    }
    setInput('');
  };

  const handlePromptClick = (e) => {
    if (e.target === inputRef.current) return;
    e.preventDefault(); e.stopPropagation();
    inputRef.current?.focus(); 
  };

  const promptPositionClass = theme.promptPosition === 'bottom' ? 'prompt-bottom' : 'prompt-top-right';

  return (
    <>
      <div className={cn("command-prompt-wrapper transition-all duration-500 z-50", promptPositionClass)}>
        {isCameraActive && (
             <div className="fixed inset-0 z-[60] bg-black flex flex-col items-center justify-center">
                 <div className="relative border-2 border-red-500 rounded-sm overflow-hidden shadow-[0_0_30px_rgba(255,0,0,0.3)]">
                     <video ref={videoRef} className="w-[80vw] max-w-[640px] h-auto" autoPlay playsInline muted />
                     <div className="absolute top-2 left-2 text-red-500 font-mono text-xs bg-black/50 px-1">REC :: @nsible_OPTICS</div>
                     <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                         <div className="w-16 h-16 border-2 border-white/30 rounded-full"></div>
                     </div>
                 </div>
                 <div className="mt-4 flex gap-4">
                     <button onClick={capturePhoto} className="px-6 py-2 bg-red-600 hover:bg-red-500 text-white font-bold font-mono tracking-widest rounded uppercase">
                         Capture {snapRecipient ? `& Send to ${snapRecipient.username}` : ''}
                     </button>
                     <button onClick={stopCamera} className="px-6 py-2 border border-zinc-600 hover:bg-zinc-800 text-zinc-400 font-mono uppercase rounded">
                         Cancel
                     </button>
                 </div>
                 <canvas ref={canvasRef} className="hidden" />
             </div>
        )}

        <form 
          onSubmit={handleSubmit} 
          className={cn("command-prompt transition-all duration-300", backgroundActivity && "shadow-[0_0_20px_rgba(220,20,60,0.6)] border-red-500/50")}
          data-has-input={!!input}
          onClick={handlePromptClick}
        >
          <span className={cn("command-prompt-prefix", backgroundActivity && "animate-pulse text-red-400")}>
              {backgroundActivity ? "(!)" : "@://"}
          </span>
          <input
            ref={inputRef} 
            type="text" 
            value={input}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            className="command-input text-sm" // Reduced font size
            autoFocus 
            autoComplete="off" 
            spellCheck="false"
            autoCorrect="off"
            autoCapitalize="none"
          />
        </form>
      </div>
      {previewData && <WebPreviewModal data={previewData} onClose={() => setPreviewData(null)} />}
    </>
  );
});

export default CommandPrompt;
