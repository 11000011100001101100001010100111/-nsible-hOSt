
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDesk } from '@/contexts/DeskContext';
import { Radio, Signal, AlertTriangle, Play, Pause, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';

const BroadcastPane = () => {
  const { frequency } = useParams();
  const { fetchUserByFrequency } = useDesk();
  const [targetUser, setTargetUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Broadcast Player State
  const [remoteTrack, setRemoteTrack] = useState(null);
  const [isRemotePlaying, setIsRemotePlaying] = useState(false);
  const audioRef = useRef(new Audio());
  const [localPlaying, setLocalPlaying] = useState(false);

  useEffect(() => {
    const loadTarget = async () => {
        if (!frequency) return;
        setLoading(true);
        setError(null);
        try {
            const user = await fetchUserByFrequency(frequency);
            if (user) {
                setTargetUser(user);
                // Initial State Load from DB
                if (user.profile_info?.broadcast_state) {
                     const state = user.profile_info.broadcast_state;
                     // Only set track if fresh enough? Or always.
                     if (state.track) {
                         setRemoteTrack(state.track);
                         setIsRemotePlaying(state.isPlaying);
                     }
                }
            } else {
                setError("NO SIGNAL DETECTED");
            }
        } catch (e) {
            setError("INTERFERENCE DETECTED");
        } finally {
            setLoading(false);
        }
    };
    loadTarget();
  }, [frequency, fetchUserByFrequency]);

  // Realtime Subscription
  useEffect(() => {
      if (!frequency) return;

      const channel = supabase.channel(`broadcast:${frequency}`)
        .on('broadcast', { event: 'track_update' }, (payload) => {
             const data = payload.payload;
             if (data) {
                 setRemoteTrack(data.track);
                 setIsRemotePlaying(data.isPlaying);
                 
                 // Auto-update audio src if changed
                 if (data.track?.url && audioRef.current.src !== data.track.url) {
                      audioRef.current.src = data.track.url;
                      // Don't auto-play without user interaction usually, but let's try if already localPlaying
                      if (localPlaying && data.isPlaying) {
                          audioRef.current.play().catch(e => console.log("Autoplay blocked", e));
                      }
                 } else if (!data.track) {
                     audioRef.current.pause();
                     audioRef.current.src = "";
                 }
             }
        })
        .subscribe();

      return () => {
          supabase.removeChannel(channel);
      };
  }, [frequency, localPlaying]);

  // Sync Local Player with Remote State
  useEffect(() => {
      if (remoteTrack && remoteTrack.url) {
          if (audioRef.current.src !== remoteTrack.url) {
              audioRef.current.src = remoteTrack.url;
          }
          
          if (isRemotePlaying && localPlaying) {
              audioRef.current.play().catch(e => console.warn("Play failed", e));
          } else {
              audioRef.current.pause();
          }
      }
  }, [remoteTrack, isRemotePlaying, localPlaying]);

  const toggleLocalPlayback = () => {
      setLocalPlaying(!localPlaying);
      if (!localPlaying) {
          // Attempt start
          audioRef.current.play().catch(e => console.warn("Start failed", e));
      } else {
          audioRef.current.pause();
      }
  };
  
  const handleDownload = () => {
      if (remoteTrack?.url) {
          const a = document.createElement('a');
          a.href = remoteTrack.url;
          a.download = remoteTrack.title || 'download.mp3';
          a.target = '_blank';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
      }
  };

  const htmlContent = targetUser?.public_page_html || 
    '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:#666;font-family:monospace;">Waiting for transmission...</div>';

  return (
    <div className="h-screen w-screen bg-black relative overflow-hidden flex flex-col">
        {/* Header Overlay */}
        <div className="absolute top-0 left-0 right-0 z-50 px-3 py-2 flex justify-between items-start pointer-events-none"> {/* Reduced padding */}
            <div className="bg-black/80 backdrop-blur border border-red-900/30 p-2 rounded-md text-red-500 flex items-center gap-2 pointer-events-auto"> {/* Reduced padding, gap, rounded */}
                <Signal className={cn("w-4 h-4", !error && "animate-pulse")} /> {/* Reduced icon size */}
                <div>
                    <h1 className="text-xs font-bold font-mono tracking-widest">{frequency}</h1> {/* Reduced font size */}
                    <p className="text-[9px] text-gray-500">{loading ? 'TUNING...' : (targetUser ? `@${targetUser.username}` : 'STATIC')}</p> {/* Reduced font size */}
                </div>
            </div>
            
            {!loading && !error && (
                 <div className="bg-red-950/80 backdrop-blur border border-red-500/30 px-2 py-0.5 rounded-full flex items-center gap-1.5 animate-pulse pointer-events-auto"> {/* Reduced padding, gap */}
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" /> {/* Reduced size */}
                    <span className="text-[9px] font-bold text-red-200">LIVE</span> {/* Reduced font size */}
                 </div>
            )}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 w-full h-full relative z-10">
            {loading ? (
                <div className="w-full h-full flex items-center justify-center">
                    <div className="w-12 h-12 border-t-2 border-red-500 rounded-full animate-spin" /> {/* Reduced size */}
                </div>
            ) : error ? (
                <div className="w-full h-full flex flex-col items-center justify-center text-red-500/50 gap-3"> {/* Reduced gap */}
                    <AlertTriangle className="w-20 h-20 opacity-50" /> {/* Reduced icon size */}
                    <h2 className="text-xl font-mono tracking-widest">{error}</h2> {/* Reduced font size */}
                </div>
            ) : (
                <iframe 
                    srcDoc={`
                        <html>
                        <head>
                            <style>
                                body { margin: 0; background: #000; color: #fff; font-family: sans-serif; overflow: hidden; }
                                ::-webkit-scrollbar { width: 5px; }
                                ::-webkit-scrollbar-thumb { background: #333; }
                            </style>
                        </head>
                        <body>${htmlContent}</body>
                        </html>
                    `}
                    className="w-full h-full border-none"
                    sandbox="allow-scripts"
                    title="Broadcast Content"
                />
            )}
        </div>

        {/* Footer / Radio Feed Overlay */}
        <div className="absolute bottom-0 left-0 right-0 z-50 px-3 py-2 pointer-events-none"> {/* Reduced padding */}
             {!loading && !error && (
                 <motion.div 
                    initial={{ y: 100 }}
                    animate={{ y: 0 }}
                    className="max-w-md mx-auto bg-black/90 backdrop-blur border-t border-red-900/50 rounded-t-lg px-3 py-2 flex items-center gap-2 pointer-events-auto shadow-2xl shadow-red-900/20" // Reduced padding, gap, rounded
                 >
                     <div className="w-8 h-8 bg-red-900/20 rounded flex items-center justify-center border border-red-500/20 relative"> {/* Reduced size */}
                         <Radio className={cn("w-4 h-4 text-red-500", (localPlaying && isRemotePlaying) && "animate-pulse")} /> {/* Reduced icon size */}
                         {isRemotePlaying && <span className="absolute -top-1 -right-1 w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" title="Signal Live" />} {/* Reduced size */}
                     </div>
                     <div className="flex-1 min-w-0">
                         <h3 className="text-xs font-bold text-white font-mono truncate"> {/* Reduced font size */}
                             {remoteTrack ? remoteTrack.title : "SIGNAL IDLE"}
                         </h3>
                         <p className="text-[8px] text-gray-500 uppercase tracking-wider truncate"> {/* Reduced font size */}
                             {remoteTrack ? `${remoteTrack.artist} // ${isRemotePlaying ? "TRANSMITTING" : "PAUSED"}` : "WAITING FOR HOST..."}
                         </p>
                     </div>
                     
                     {remoteTrack && remoteTrack.url && (
                        <Button size="icon" variant="ghost" className="h-7 w-7 text-gray-400 hover:text-white" onClick={handleDownload} title="Download Artifact"> {/* Reduced size */}
                             <Download className="w-3.5 h-3.5" /> {/* Reduced icon size */}
                        </Button>
                     )}

                     <Button size="icon" variant="ghost" className="h-7 w-7 text-white hover:bg-white/10" onClick={toggleLocalPlayback} disabled={!remoteTrack}> {/* Reduced size */}
                         {localPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />} {/* Reduced icon size */}
                     </Button>
                 </motion.div>
             )}
        </div>
    </div>
  );
};

export default BroadcastPane;
