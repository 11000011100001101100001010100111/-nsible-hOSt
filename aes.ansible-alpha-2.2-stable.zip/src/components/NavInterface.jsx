
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';
import { 
  Compass, Plus, Minus, Crosshair, LocateFixed, 
  Layers, Check, Search as SearchIcon, Map as MapIcon,
  Loader2, Globe, Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useDesk } from '@/contexts/DeskContext';

// --- MATH UTILITIES FOR SLIPPY MAPS ---
const TILE_SIZE = 256;
const lon2tile = (lon, zoom) => (lon + 180) / 360 * Math.pow(2, zoom);
const lat2tile = (lat, zoom) => (1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom);
const tile2lon = (x, z) => x / Math.pow(2, z) * 360 - 180;
const tile2lat = (y, z) => {
  const n = Math.PI - 2 * Math.PI * y / Math.pow(2, z);
  return 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
};

// --- MAP LAYERS ---
const MAP_LAYERS = [
  {
    id: 'carto_dark',
    name: 'CartoDB Dark Matter',
    url: (x, y, z) => `https://a.basemaps.cartocdn.com/dark_all/${z}/${x}/${y}.png`,
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    style: 'invert-0'
  },
  {
    id: 'osm_standard',
    name: 'OpenStreetMap Standard',
    url: (x, y, z) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`,
    attribution: '&copy; OpenStreetMap contributors',
    style: 'invert-[0.9] hue-rotate-180 saturate-50' 
  },
  {
    id: 'esri_sat',
    name: 'Esri Satellite',
    url: (x, y, z) => `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`,
    attribution: 'Tiles &copy; Esri',
    style: 'grayscale-[0.3] contrast-125'
  }
];

// --- STORAGE UTILS ---
const NAV_STORAGE_KEY = 'ansible_nav_pos_enc';
const encryptPos = (pos) => {
  try {
    const str = JSON.stringify(pos);
    const key = 'ansible-nav-key'; 
    let encrypted = '';
    for (let i = 0; i < str.length; i++) encrypted += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    return btoa(encrypted);
  } catch (e) { return null; }
};
const decryptPos = (cipher) => {
  try {
    const str = atob(cipher);
    const key = 'ansible-nav-key';
    let decrypted = '';
    for (let i = 0; i < str.length; i++) decrypted += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    return JSON.parse(decrypted);
  } catch (e) { return null; }
};

// --- GHOST CURSOR ---
const GhostCursor = () => {
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);
  const springConfig = { damping: 20, stiffness: 400, mass: 0.5 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  useEffect(() => {
    const moveCursor = (e) => { cursorX.set(e.clientX); cursorY.set(e.clientY); };
    window.addEventListener('mousemove', moveCursor);
    return () => window.removeEventListener('mousemove', moveCursor);
  }, [cursorX, cursorY]);

  return (
    <motion.div
      className="fixed top-0 left-0 pointer-events-none z-[100] mix-blend-screen"
      style={{ x: cursorXSpring, y: cursorYSpring, translateX: '-50%', translateY: '-50%' }}
    >
      <div className="relative flex items-center justify-center w-12 h-12">
        <motion.div 
            animate={{ rotate: 360, scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 bg-gradient-to-tr from-red-600 via-orange-500 to-transparent rounded-full blur-sm"
        />
        <Crosshair className="w-6 h-6 text-white/80 absolute z-10 opacity-80" strokeWidth={1} />
      </div>
    </motion.div>
  );
};

// --- MAIN COMPONENT ---
const NavInterface = () => {
  const { toast } = useToast();
  const { addCommandOutput } = useDesk();
  
  // -- MAP STATE --
  const [center, setCenter] = useState({ lat: 40.7128, lon: -74.0060 });
  const [zoom, setZoom] = useState(13);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [activeLayerIdx, setActiveLayerIdx] = useState(0);
  const [isLayerMenuOpen, setIsLayerMenuOpen] = useState(false);
  const [isTracking, setIsTracking] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  
  // -- TOUCH STATE --
  const lastTouchRef = useRef(null);
  const initialPinchDistRef = useRef(null);
  const initialZoomRef = useRef(null);

  // -- SEARCH STATE --
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  
  // -- UI STATE --
  const [uiVisible, setUiVisible] = useState(true);
  const [containerSize, setContainerSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  
  const mapContainerRef = useRef(null);
  const uiTimeoutRef = useRef(null);
  const watchIdRef = useRef(null);
  
  // -- THROTTLING REFS --
  const lastUpdateRef = useRef(0);
  const UPDATE_THROTTLE_MS = 2500;

  // -- RESTORE SAVED POSITION --
  useEffect(() => {
    const savedCipher = localStorage.getItem(NAV_STORAGE_KEY);
    if (savedCipher) {
      const decrypted = decryptPos(savedCipher);
      if (decrypted && decrypted.lat && decrypted.lon && decrypted.zoom) {
        setCenter({ lat: decrypted.lat, lon: decrypted.lon });
        setZoom(decrypted.zoom);
      }
    }
  }, []);

  // -- PERSIST POSITION --
  useEffect(() => {
    const pos = { lat: center.lat, lon: center.lon, zoom };
    const cipher = encryptPos(pos);
    if (cipher) localStorage.setItem(NAV_STORAGE_KEY, cipher);
  }, [center, zoom]);

  // -- COMMAND LISTENER --
  useEffect(() => {
    const handleCommand = (e) => {
        const cmd = e.detail?.command?.toLowerCase().trim();
        if (!cmd) return;

        if (cmd === 'nav track') {
            setIsTracking(true);
            const ts = new Date().toLocaleTimeString();
            addCommandOutput({ type: 'success', title: 'NAV', message: `[${ts}] Auto-tracking INITIATED.` });
        } else if (cmd === 'nav null') {
            setIsTracking(false);
            if (watchIdRef.current) navigator.geolocation.clearWatch(watchIdRef.current);
            const ts = new Date().toLocaleTimeString();
            addCommandOutput({ type: 'info', title: 'NAV', message: `[${ts}] Auto-tracking TERMINATED.` });
        }
    };
    window.addEventListener('ansible-command', handleCommand);
    return () => window.removeEventListener('ansible-command', handleCommand);
  }, [addCommandOutput]);

  // -- GPS TRACKING LOGIC --
  useEffect(() => {
    if (isTracking) {
        if (!navigator.geolocation) {
             toast({ title: "Error", description: "Geolocation not supported", variant: "destructive" });
             setIsTracking(false);
             return;
        }

        lastUpdateRef.current = 0;

        watchIdRef.current = navigator.geolocation.watchPosition(
            (pos) => {
                const now = Date.now();
                if (now - lastUpdateRef.current < UPDATE_THROTTLE_MS) return;
                
                if (isDragging) return;

                setCenter({ lat: pos.coords.latitude, lon: pos.coords.longitude });
                lastUpdateRef.current = now;
            },
            (err) => {
                console.error(err);
                setIsTracking(false);
                toast({ title: "Signal Lost", description: "GPS tracking failed.", variant: "destructive" });
                addCommandOutput({ type: 'error', title: 'NAV', message: 'Signal lost during tracking sequence.' });
            },
            { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
        );
    } else {
        if (watchIdRef.current) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
        }
    }
    return () => {
        if (watchIdRef.current) navigator.geolocation.clearWatch(watchIdRef.current);
    };
  }, [isTracking, toast, isDragging, addCommandOutput]);

  // -- RESIZE HANDLER --
  useEffect(() => {
    const handleResize = () => setContainerSize({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // -- UI AUTO-HIDE --
  const resetUiTimeout = useCallback(() => {
    setUiVisible(true);
    if (uiTimeoutRef.current) clearTimeout(uiTimeoutRef.current);
    uiTimeoutRef.current = setTimeout(() => setUiVisible(false), 3000);
  }, []);

  useEffect(() => {
    resetUiTimeout();
    const events = ['mousemove', 'keydown', 'touchstart'];
    events.forEach(e => window.addEventListener(e, resetUiTimeout));
    return () => {
      events.forEach(e => window.removeEventListener(e, resetUiTimeout));
      if (uiTimeoutRef.current) clearTimeout(uiTimeoutRef.current);
    };
  }, [resetUiTimeout]);

  // -- TILE GENERATION --
  const getVisibleTiles = () => {
    const tiles = [];
    const centerTileX = lon2tile(center.lon, zoom);
    const centerTileY = lat2tile(center.lat, zoom);
    
    const tilesX = Math.ceil(containerSize.width / TILE_SIZE) + 2;
    const tilesY = Math.ceil(containerSize.height / TILE_SIZE) + 2;
    
    const startX = Math.floor(centerTileX - tilesX / 2);
    const startY = Math.floor(centerTileY - tilesY / 2);
    
    const centerXOffset = (centerTileX % 1) * TILE_SIZE;
    const centerYOffset = (centerTileY % 1) * TILE_SIZE;
    
    const screenCenterX = containerSize.width / 2;
    const screenCenterY = containerSize.height / 2;

    for (let x = startX; x < startX + tilesX; x++) {
      for (let y = startY; y < startY + tilesY; y++) {
        const maxTiles = Math.pow(2, zoom);
        const wrappedX = ((x % maxTiles) + maxTiles) % maxTiles;
        if (y < 0 || y >= maxTiles) continue;

        const tileDistX = x - Math.floor(centerTileX);
        const tileDistY = y - Math.floor(centerTileY);
        
        const posX = screenCenterX + (tileDistX * TILE_SIZE) - centerXOffset + offset.x;
        const posY = screenCenterY + (tileDistY * TILE_SIZE) - centerYOffset + offset.y;
        
        tiles.push({
          key: `${zoom}-${x}-${y}`,
          x: wrappedX,
          y: y,
          z: zoom,
          posX,
          posY
        });
      }
    }
    return tiles;
  };

  // -- INTERACTION HANDLERS --
  const handleDragStart = () => {
      setIsDragging(true);
  };

  const handleDragEnd = (event, info) => {
    setIsDragging(false);
    
    if (isTracking) {
        setIsTracking(false);
        const ts = new Date().toLocaleTimeString();
        addCommandOutput({ type: 'info', title: 'NAV', message: `[${ts}] Tracking interrupted by manual input.` });
        toast({ title: "Tracking Paused", description: "Manual control resumed." });
    }

    const deltaX = info.offset.x; 
    const deltaY = info.offset.y;
    
    const tilesMovedX = -deltaX / TILE_SIZE;
    const tilesMovedY = -deltaY / TILE_SIZE;
    
    const currentTileX = lon2tile(center.lon, zoom);
    const currentTileY = lat2tile(center.lat, zoom);
    
    const newLon = tile2lon(currentTileX + tilesMovedX, zoom);
    const newLat = tile2lat(currentTileY + tilesMovedY, zoom);
    
    setCenter({ lat: newLat, lon: newLon });
    setOffset({ x: 0, y: 0 });
  };

  const handleZoom = (direction) => {
    setZoom(prev => Math.max(2, Math.min(direction === 'in' ? prev + 1 : prev - 1, 19)));
  };

  const handleLocateMe = () => {
     setIsTracking(true);
     toast({ title: "Acquiring Signal", description: "Locking on GPS..." });
     if (!isTracking) {
         const ts = new Date().toLocaleTimeString();
         addCommandOutput({ type: 'success', title: 'NAV', message: `[${ts}] GPS lock requested.` });
     }
  };

  // -- TOUCH CONTROLS --
  const handleTouchStart = (e) => {
    if (e.touches.length === 2) {
      const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      initialPinchDistRef.current = dist;
      initialZoomRef.current = zoom;
    } else if (e.touches.length === 1) {
      lastTouchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const handleTouchMove = (e) => {
    if (e.touches.length === 2 && initialPinchDistRef.current) {
        e.preventDefault();
        const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        const scale = dist / initialPinchDistRef.current;
        if (Math.abs(scale - 1) > 0.2) {
            const zoomDelta = scale > 1 ? 1 : -1;
            const newZoom = Math.max(2, Math.min(initialZoomRef.current + zoomDelta, 19));
            if (newZoom !== zoom) {
                setZoom(newZoom);
                initialPinchDistRef.current = dist;
                initialZoomRef.current = newZoom;
            }
        }
    }
  };

  const handleTouchEnd = () => {
    initialPinchDistRef.current = null;
    initialZoomRef.current = null;
    lastTouchRef.current = null;
  };

  // -- SEARCH LOGIC --
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    if (isTracking) {
        setIsTracking(false);
        const ts = new Date().toLocaleTimeString();
        addCommandOutput({ type: 'info', title: 'NAV', message: `[${ts}] Tracking suspended for search jump.` });
    }

    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`);
      const data = await res.json();
      
      if (data?.length > 0) {
        if (data.length === 1) {
          const result = data[0];
          setCenter({ lat: parseFloat(result.lat), lon: parseFloat(result.lon) });
          setZoom(14);
          setSearchResults([]);
          setSearchQuery('');
          toast({ title: "Target Acquired", description: `Jumping to ${result.display_name.split(',')[0]}` });
        } else {
          setSearchResults(data);
        }
      } else {
        toast({ title: "Search Failed", description: "No locations found.", variant: "destructive" });
      }
    } catch (err) {
      toast({ title: "Network Error", description: "Could not reach positioning satellites.", variant: "destructive" });
    } finally {
      setIsSearching(false);
    }
  };

  const selectSearchResult = (result) => {
    setCenter({ lat: parseFloat(result.lat), lon: parseFloat(result.lon) });
    setZoom(14);
    setSearchResults([]);
    setSearchQuery('');
  };

  const activeLayer = MAP_LAYERS[activeLayerIdx];
  const tiles = getVisibleTiles();

  return (
    <div 
        className="h-screen w-screen relative bg-[#1a1a1a] overflow-hidden font-mono text-xs cursor-none touch-none"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
    >
      <Helmet> <title>Global Navigation | @nsible</title> </Helmet>
      <GhostCursor />

      <motion.div 
        ref={mapContainerRef}
        className="absolute inset-0 touch-none"
        drag
        dragMomentum={false}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        key={`map-container-${zoom}-${center.lat}-${center.lon}`} 
      >
        <div className="relative w-full h-full">
            {tiles.map(tile => (
                <img
                    key={tile.key}
                    src={activeLayer.url(tile.x, tile.y, tile.z)}
                    alt=""
                    className={cn("map-tile absolute transition-opacity duration-300 pointer-events-none select-none", activeLayer.style)}
                    style={{ left: tile.posX, top: tile.posY }}
                    draggable={false}
                />
            ))}
        </div>
      </motion.div>

      <div className="absolute bottom-0.5 right-0.5 text-[9px] text-white/20 pointer-events-none z-0">
         <span dangerouslySetInnerHTML={{__html: activeLayer.attribution}} />
      </div>

      <AnimatePresence>
        {uiVisible && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-4 pb-20"> {/* Added pb-20 to prevent overlap with RadioBar */}
            <div className="flex justify-between items-start pointer-events-auto">
                <div className="bg-black/80 backdrop-blur-md border border-white/10 rounded-br-lg p-3 shadow-xl max-w-[220px] cursor-none">
                    <div className="flex items-center gap-1.5 mb-2 text-red-500">
                        <MapIcon className="w-4 h-4" />
                        <span className="font-bold tracking-widest text-xs">NAV.SYSTEM</span>
                        {isTracking && <Lock className="w-2.5 h-2.5 animate-pulse" />}
                    </div>
                    <div className="grid grid-cols-2 gap-1.5 text-[10px] text-muted-foreground mb-3 font-mono">
                        <div><span className="block text-[8px] uppercase opacity-50">Latitude</span><span className="text-white">{center.lat.toFixed(5)}° N</span></div>
                        <div><span className="block text-[8px] uppercase opacity-50">Longitude</span><span className="text-white">{center.lon.toFixed(5)}° E</span></div>
                        <div><span className="block text-[8px] uppercase opacity-50">Zoom Level</span><span className="text-white">LVL {zoom}</span></div>
                        <div><span className="block text-[8px] uppercase opacity-50">Status</span><span className={cn("text-white font-bold", isTracking ? "text-green-500" : "text-yellow-500")}>{isTracking ? "LOCKED" : "MANUAL"}</span></div>
                    </div>
                    <form onSubmit={handleSearch} className="relative cursor-none">
                         <SearchIcon className="absolute left-1.5 top-1.5 w-3.5 h-3.5 text-white/50" />
                         <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onFocus={resetUiTimeout} placeholder="Target Search..." className="pl-7 bg-white/5 border-white/10 text-white placeholder:text-white/30 text-[10px] h-7 cursor-none focus:cursor-text" />
                         {isSearching && <Loader2 className="absolute right-1.5 top-1.5 w-3.5 h-3.5 text-red-500 animate-spin" />}
                    </form>
                    {searchResults.length > 0 && (
                        <div className="mt-1.5 bg-black/90 border border-white/10 rounded max-h-32 overflow-y-auto cursor-none">
                            {searchResults.map((res, i) => (
                                <button key={i} onClick={() => selectSearchResult(res)} className="w-full text-left px-1.5 py-1 text-[9px] text-white hover:bg-white/10 border-b border-white/5 last:border-0 truncate cursor-none">{res.display_name}</button>
                            ))}
                        </div>
                    )}
                </div>
                <div className="bg-black/80 backdrop-blur-md border border-white/10 rounded-bl-lg p-2 flex items-center gap-2">
                    <div className="text-right">
                        <div className="text-[8px] text-white/50 uppercase">Data Stream</div>
                        <div className="text-[9px] text-green-500 font-bold animate-pulse">LIVE FEED</div>
                    </div>
                    <Globe className="w-6 h-6 text-white/10" />
                </div>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-20">
                <Crosshair className={cn("w-24 h-24 transition-colors duration-500", isTracking ? "text-green-500" : "text-red-500/50")} strokeWidth={0.5} />
            </div>
            <div className="flex justify-between items-end pointer-events-auto">
                 <div className="bg-black/80 backdrop-blur-md border border-white/10 rounded-tr-lg p-1.5 flex gap-1.5 cursor-none">
                     <div className="flex flex-col gap-1">
                         <Button size="icon" variant="outline" className="h-7 w-7 bg-white/5 border-white/10 hover:bg-white/10 hover:text-white cursor-none" onClick={() => handleZoom('in')}><Plus className="w-3.5 h-3.5" /></Button>
                         <Button size="icon" variant="outline" className="h-7 w-7 bg-white/5 border-white/10 hover:bg-white/10 hover:text-white cursor-none" onClick={() => handleZoom('out')}><Minus className="w-3.5 h-3.5" /></Button>
                     </div>
                     <div className="w-px bg-white/10 mx-0.5" />
                     <div className="flex flex-col gap-1 relative">
                         <Button size="icon" variant="ghost" className={cn("h-7 w-7 hover:bg-white/10 cursor-none", isTracking ? "text-green-500 bg-white/10" : "hover:text-red-400")} onClick={handleLocateMe} title="Locate GPS"><LocateFixed className="w-3.5 h-3.5" /></Button>
                         <Button size="icon" variant="ghost" className={cn("h-7 w-7 hover:bg-white/10 cursor-none", isLayerMenuOpen ? "text-red-400 bg-white/10" : "hover:text-red-400")} onClick={() => setIsLayerMenuOpen(!isLayerMenuOpen)} title="Map Layers"><Layers className="w-3.5 h-3.5" /></Button>
                         <AnimatePresence>
                             {isLayerMenuOpen && (
                                 <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }} className="absolute bottom-0 left-full ml-1.5 w-40 bg-black/90 border border-white/10 rounded p-0.5 shadow-xl z-50 cursor-none">
                                     {MAP_LAYERS.map((layer, idx) => (
                                         <button key={layer.id} onClick={() => { setActiveLayerIdx(idx); setIsLayerMenuOpen(false); }} className={cn("w-full text-left px-1.5 py-1 text-[9px] flex items-center justify-between rounded hover:bg-white/10 cursor-none", activeLayerIdx === idx ? "text-white bg-white/5" : "text-gray-400")}>
                                             {layer.name} {activeLayerIdx === idx && <Check className="w-3 h-3 text-red-500" />}
                                         </button>
                                     ))}
                                 </motion.div>
                             )}
                         </AnimatePresence>
                     </div>
                 </div>
                 <div className="bg-black/80 backdrop-blur-md border border-white/10 rounded-tl-lg p-3 text-center">
                    <Compass className={cn("w-8 h-8 text-white/20 mx-auto transition-transform duration-500")} style={{ transform: `rotate(${offset.x * 0.1}deg)` }} />
                    <div className="text-[8px] text-white/30 mt-0.5 font-mono">N {Math.abs(center.lat).toFixed(1)} / W {Math.abs(center.lon).toFixed(1)}</div>
                 </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NavInterface;
