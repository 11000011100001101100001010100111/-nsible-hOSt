
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Radio, User, LogIn, Activity } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const BroadcastModal = ({ isOpen, onClose, streamData }) => {
  const navigate = useNavigate();
  const [isConnecting, setIsConnecting] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setIsConnecting(true);
      const timer = setTimeout(() => setIsConnecting(false), 1200); // Reduced connection time
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleGuestEntry = () => {
    if (streamData?.freq) {
        navigate(`/freq/${streamData.freq}`);
    }
    onClose();
  };

  const handleLoginRedirect = () => {
    onClose();
    window.dispatchEvent(new CustomEvent('toggleLoginModal'));
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-3" // Reduced padding
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="w-full max-w-sm bg-black border border-red-900/50 rounded-lg overflow-hidden shadow-2xl relative" // Reduced max-width, rounded corners
        >
          {/* Header */}
          <div className="bg-red-950/20 border-b border-red-900/30 px-3 py-2 flex items-center justify-between"> {/* Reduced padding */}
             <div className="flex items-center gap-1.5 text-red-500"> {/* Reduced gap */}
                <Radio className="w-4 h-4 animate-pulse" /> {/* Reduced icon size */}
                <span className="font-mono font-bold tracking-widest text-xs">SECURE BROADCAST</span> {/* Reduced font size */}
             </div>
             <div className="flex items-center gap-1.5"> {/* Reduced gap */}
                 <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" /> {/* Reduced size */}
                 <span className="text-[9px] text-red-400 font-mono">LIVE FEED</span> {/* Reduced font size */}
             </div>
          </div>

          {/* Content */}
          <div className="p-6 text-center space-y-4"> {/* Reduced padding, space-y */}
             {isConnecting ? (
                 <div className="py-6 space-y-3"> {/* Reduced padding, space-y */}
                    <Activity className="w-10 h-10 text-red-500 mx-auto animate-bounce" /> {/* Reduced icon size */}
                    <p className="text-red-400 font-mono text-xs animate-pulse">DECRYPTING SIGNAL...</p> {/* Reduced font size */}
                 </div>
             ) : (
                 <>
                    <div className="space-y-1.5"> {/* Reduced space-y */}
                        <h2 className="text-xl font-bold text-white font-mono"> {/* Reduced font size */}
                            {streamData?.title || "Unknown Transmission"}
                        </h2>
                        <p className="text-gray-400 text-xs"> {/* Reduced font size */}
                            Incoming transmission from <span className="text-red-400">@://{streamData?.user || "anonymous"}</span>
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-3 pt-3"> {/* Reduced gap, pt */}
                        <Button 
                            onClick={handleGuestEntry}
                            className="bg-white text-black hover:bg-gray-200 font-bold h-10 border-none text-sm" // Reduced height, font size
                        >
                            <User className="w-3.5 h-3.5 mr-1.5" /> {/* Reduced icon size, margin */}
                            JOIN FREQUENCY
                        </Button>
                        
                        <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <span className="w-full border-t border-white/10" />
                            </div>
                            <div className="relative flex justify-center text-[10px] uppercase"> {/* Reduced font size */}
                                <span className="bg-black px-1.5 text-gray-500">Authorized Personnel</span> {/* Reduced padding */}
                            </div>
                        </div>

                        <Button 
                            variant="outline"
                            onClick={handleLoginRedirect}
                            className="border-red-900/50 text-red-500 hover:bg-red-950/30 h-10 text-sm" // Reduced height, font size
                        >
                            <LogIn className="w-3.5 h-3.5 mr-1.5" /> {/* Reduced icon size, margin */}
                            AUTHENTICATE
                        </Button>
                    </div>
                 </>
             )}
          </div>

          {/* Footer */}
          <div className="bg-black p-2 text-center border-t border-white/5"> {/* Reduced padding */}
             <p className="text-[9px] text-gray-600 font-mono"> {/* Reduced font size */}
                 ENCRYPTION: AES-256 // PROTOCOL: @NSIBLE-STREAM-V2
             </p>
          </div>

        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default BroadcastModal;
