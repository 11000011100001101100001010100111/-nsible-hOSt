
import React, { useEffect, useRef, Suspense, lazy, useState } from 'react';
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import IntroScreen from '@/components/IntroScreen';
import CommandPrompt from '@/components/CommandPrompt';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ThemeLoader from '@/components/ThemeLoader';
import { useDesk } from '@/contexts/DeskContext';
import { useTheme } from '@/contexts/ThemeContext';
import { cn } from '@/lib/utils';
import LoginModal from '@/components/LoginModal';
import MatrixRain from '@/components/MatrixRain';
import DeskIcon from '@/components/ui/DeskIcon';
import RadioBar from '@/components/RadioBar';
import WebFrame from '@/components/WebFrame'; 
import BroadcastPane from '@/components/BroadcastPane'; 
import BroadcastModal from '@/components/BroadcastModal';

const AnsibleDesk = lazy(() => import('@/components/AnsibleDesk'));
const LaboratoryWelcome = lazy(() => {
  const event = new CustomEvent('moduleLoading', { detail: { module: 'Laboratory' } });
  window.dispatchEvent(event);
  return import('@/components/LaboratoryWelcome');
});
const NavInterface = lazy(() => {
  const event = new CustomEvent('moduleLoading', { detail: { module: 'Navigation' } });
  window.dispatchEvent(event);
  return import('@/components/NavInterface');
});

const CYCLE_SECONDS = 42 * 60 + 8;
const IDLE_TIMEOUT_TO_LAB = CYCLE_SECONDS * 0.4 * 1000;
const LOGOUT_TIMEOUT = CYCLE_SECONDS * 1000;

function App() {
  const { user, loading } = useAuth();
  const { isDeskOpen, isDeskLoading, addCommandOutput, logToVoid, openDesk } = useDesk(); // Removed hasUnreadMessages
  const { theme, setTheme } = useTheme();
  const commandPromptRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();
  const idleTimerRef = useRef(null);
  const logoutTimerRef = useRef(null);
  
  // Modal States
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [broadcastModalState, setBroadcastModalState] = useState({ isOpen: false, data: null });
  
  const hasLoggedFinalNote = useRef(false);

  useEffect(() => {
    if (user && !loading && !hasLoggedFinalNote.current) {
      logToVoid(`
        FINALE - STABLE BUILD ACHIEVED
        =================================
        Architecte,
        Notre collaboration a atteint son apogée.
      `);
      hasLoggedFinalNote.current = true;
    }
  }, [user, loading, logToVoid]);

  useEffect(() => {
    const toggleLoginModal = () => setIsLoginModalOpen(prev => !prev);
    const openBroadcastModal = (e) => setBroadcastModalState({ isOpen: true, data: e.detail });
    
    window.addEventListener('toggleLoginModal', toggleLoginModal);
    window.addEventListener('openBroadcastModal', openBroadcastModal);
    
    return () => {
        window.removeEventListener('toggleLoginModal', toggleLoginModal);
        window.removeEventListener('openBroadcastModal', openBroadcastModal);
    };
  }, []);

  useEffect(() => {
    const handleModuleLoading = (e) => {
      addCommandOutput({ type: 'info', title: 'System', message: `Loading ${e.detail.module} module...` });
    };
    window.addEventListener('moduleLoading', handleModuleLoading);
    return () => window.removeEventListener('moduleLoading', handleModuleLoading);
  }, [addCommandOutput]);

  const handleUserActivity = () => {
    clearTimeout(idleTimerRef.current);
    clearTimeout(logoutTimerRef.current);
    if (user) {
      idleTimerRef.current = setTimeout(() => {
        if (location.pathname !== '/laboratory' && location.pathname !== '/nav') {
            addCommandOutput({ type: 'info', title: 'System', message: 'User idle. Entering Laboratory...' });
            navigate('/laboratory');
        }
      }, IDLE_TIMEOUT_TO_LAB);
      logoutTimerRef.current = setTimeout(() => {
        addCommandOutput({ type: 'info', title: 'System', message: 'User inactive. Logging out for security.' });
        const signOutEvent = new CustomEvent('signOut');
        window.dispatchEvent(signOutEvent);
      }, LOGOUT_TIMEOUT);
    }
  };

  useEffect(() => {
    const events = ['mousemove', 'keydown', 'mousedown', 'touchstart'];
    events.forEach(event => window.addEventListener(event, handleUserActivity));
    handleUserActivity();

    return () => {
      events.forEach(event => window.removeEventListener(event, handleUserActivity));
      clearTimeout(idleTimerRef.current);
      clearTimeout(logoutTimerRef.current);
    };
  }, [user, navigate, addCommandOutput, location.pathname]);

  useEffect(() => {
    const handleGlobalKeyDown = (e) => {
      const target = e.target;
      const isTextInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;
      const activeElement = document.activeElement;
      const isActiveInput = activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA' || activeElement.isContentEditable);
      
      if (location.pathname === '/nav' && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', '+', '-'].includes(e.key)) return;
      if (location.pathname === '/laboratory' && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) return;

      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        if (theme.kiosk) {
          setTheme({ kiosk: false });
          if (document.fullscreenElement) document.exitFullscreen().catch(console.error);
        }
        commandPromptRef.current?.focusInput();
        return;
      }

      if (!isTextInput && !isActiveInput && !e.metaKey && !e.ctrlKey && !e.altKey) {
        if (e.key.length === 1 || e.key === 'Backspace' || e.key === 'Enter') {
           commandPromptRef.current?.focusInput();
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [theme.kiosk, setTheme, location.pathname]);

  if (loading) {
    return <div className="h-screen w-screen flex items-center justify-center bg-black themed-text-primary terminal-text pulsing-perimeter-red">INITIALIZING @NSIBLE INTERFACE...</div>;
  }
  
  const perimeterGlowClass = isDeskLoading ? 'pulsing-perimeter-red' : '';

  return (
    <>
      <Helmet>
        <title>Æ§ Technologies | @nsible Interface</title>
        <meta name="description" content="@nsible: Un protocole web évolué." />
      </Helmet>
      <ThemeLoader />
      <div className={cn("h-screen w-screen overflow-hidden bg-black relative transition-opacity duration-[3000ms]", perimeterGlowClass)}>
        {location.pathname === '/main' && <MatrixRain color="rgba(128, 128, 128, 0.1)" />}
        
        {user && !theme.kiosk && !isDeskOpen && location.pathname !== '/laboratory' && location.pathname !== '/nav' && (
          <div 
            className="absolute inset-0 z-30 flex items-center justify-center pointer-events-auto cursor-pointer animate-fade-in" 
            onClick={openDesk}
          >
            {/* Reduced size for DeskIcon */}
            <DeskIcon className={cn("w-16 h-16 text-red-500/70 transition-all duration-1000 opacity-50 hover:opacity-100 hover:scale-110")} />
          </div>
        )}

        <CommandPrompt ref={commandPromptRef} />
        
        <Suspense fallback={null}>
          <Routes>
            <Route path="/freq/:frequency" element={<BroadcastPane />} />
            <Route path="/" element={user ? <Navigate to="/main" /> : <IntroScreen />} />
            <Route path="/main" element={user ? null : <Navigate to="/" />} />
            <Route path="/laboratory" element={user ? <LaboratoryWelcome /> : <Navigate to="/" />} />
            <Route path="/nav" element={user ? <NavInterface /> : <Navigate to="/" />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
          {user && <AnsibleDesk />}
        </Suspense>

        {user && (
          <>
            <RadioBar />
            <WebFrame />
          </>
        )}

        <LoginModal isOpen={isLoginModalOpen} setIsOpen={setIsLoginModalOpen} />
        <BroadcastModal 
            isOpen={broadcastModalState.isOpen} 
            onClose={() => setBroadcastModalState(prev => ({ ...prev, isOpen: false }))}
            streamData={broadcastModalState.data}
        />
        <Toaster />
      </div>
    </>
  );
}

export default App;
